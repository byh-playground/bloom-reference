// A deliberately small host, using exactly the same runtime as the lab.
// No lab controls, effect algorithms, or GPU implementation are copied here.
export function startStandalone(SDK, preset) {
    const { WebGLDevice, BloomEffects, resolveConfig } = SDK;
    const canvas = document.querySelector('canvas'), device = new WebGLDevice(canvas, { alpha: true, depth: false, stencil: false });
    const effects = new BloomEffects({ device }), definition = SDK.definitionFor(preset.effect), config = resolveConfig(preset.effect, preset.config);
    // Caller-owned example subject. Replace these points/callback with the game's unit geometry.
    const cells = [];
    for (let y = -35; y <= 0; y += 4)
        for (let x = -15; x <= 15; x += 4)
            if (x * x / 225 + (y + 18) ** 2 / 324 <= 1)
                cells.push([x, y]);
    const subject = { cells, draw(g, { x, y, scale, color, alpha }) { g.scope(x, y, scale, () => { g.disc(0, -18, 18, color, alpha); g.line(-13, -15, 13, -15, 3, '#e3fff0', alpha * .5); }); } };
    let handle = null, last = 0, paused = false, center = { x: 0, y: 0 }, ageMs = 0;
    function spawn() {
        if (handle?.alive)
            effects.stop(handle);
        ageMs = 0;
        handle = effects.spawn(preset.effect, { config, data:preset.data||{}, seed: preset.seed, position: center, source: { x: center.x - 93, y: center.y }, target: { x: center.x + 83, y: center.y }, subject, loop: definition.type === 'continuous' });
        return handle;
    }
    function render(deltaMs = 0) {
        if (device.gl.isContextLost())
            return;
        const width = innerWidth, height = innerHeight;
        center = { x: width / 2, y: height / 2 };
        if (handle?.alive)
            effects.setAnchors(handle, { position: center, source: { x: center.x - 93, y: center.y }, target: { x: center.x + 83, y: center.y } });
        if (!paused) {
            ageMs += deltaMs;
            effects.update(deltaMs);
        }
        const dpr = Math.min(devicePixelRatio || 1, 2);
        if (device.beginFrame({ width: Math.round(width * dpr), height: Math.round(height * dpr), clearColor: [.04, .07, .09, 1] })) {
            effects.render({ width, height });
            device.endFrame();
        }
        document.querySelector('#status').textContent = `${Math.round(ageMs)} ms · ${effects.size} 활성 · ${device.stats.drawCalls} draw · ${handle?.state}`;
    }
    function frame(now) { const deltaMs = last ? Math.min(200, now - last) : 0; last = now; render(deltaMs); requestAnimationFrame(frame); }
    document.querySelector('#restart').onclick = () => { paused = false; spawn(); };
    document.querySelector('#pause').onclick = () => { paused = !paused; };
    document.querySelector('#title').textContent = definition.name + ' · 독립 실행';
    center = { x: innerWidth / 2, y: innerHeight / 2 };
    spawn();
    render();
    requestAnimationFrame(frame);
    window.BLOOM_EXAMPLE = { effects, device, spawn, get handle() { return handle; }, setPaused(v) { paused = v; }, seek(age) {
            if (!handle?.alive)
                spawn();
            effects.seek(handle, age);
            ageMs = age;
            paused = true;
            render();
        }, render, config };
}
