import {BloomEffects,catalog,resolveConfig,parametersFor,patchAt,getPath} from '../bloom-effects.js';
import {createHash} from 'node:crypto';import {writeFileSync} from 'node:fs';
const device={createPipeline(){return{}},createVertexBuffer(){return{}},uploadVertices(_,data){if(!data.every(Number.isFinite))throw Error('Nonfinite')},draw(){},deletePipeline(){},deleteVertexBuffer(){}};
const fx=new BloomEffects({device});const g=fx.geometry;
let items=[],dead=[],errors=[];
const subject={cells:[[0,-40],[0,-20],[5,0]],draw(g,{x,y,scale,color,alpha}){g.scope(x,y,scale,()=>g.disc(0,0,10,color,alpha))},bounds:{minY:-48,maxY:12}};
function hash(h,duration){let hsh=createHash('sha256');for(const t of [.025,.07,.15,.25,.37,.5,.63,.77,.9]){fx.seek(h,t*duration);g.begin({width:640,height:400,transform:{x:320,y:200}});fx.draw(h);if(!g.data.subarray(0,g.n).every(Number.isFinite))throw Error('Nonfinite');hsh.update(g.data.subarray(0,g.n));}return hsh.digest('hex');}
for(const def of catalog){let h;try{h=fx.spawn(def.id,{clock:'external',data:def.demo||{},source:{x:-93,y:0},target:{x:83,y:0},subject});const base=resolveConfig(def.id);
 const descriptors=[...parametersFor(def.id),...(base.appearance.glow!==undefined?[{key:'glow',path:'appearance.glow',min:false,max:true}]:[]),{key:'color',path:'appearance.color',min:'#ff3300',max:'#0077ff'}];
 for(const spec of descriptors){try{const a=spec.key==='swingStart'?-1.1:spec.key==='size'?.5:spec.key==='duration'?1000:spec.min;const b=spec.key==='swingStart'?1.1:spec.key==='size'?1.5:spec.key==='duration'?9000:spec.max;
 fx.configure(h,base);fx.configure(h,patchAt(spec.path,a));const ah=hash(h,def.durationMs);
 fx.configure(h,base);fx.configure(h,patchAt(spec.path,b));const bh=hash(h,def.durationMs);
 const item={effect:def.id,path:spec.path,changed:ah!==bh,consumer:'geometry'};
 if(!item.changed&&spec.key==='duration'&&def.family==='feedback'&&def.type==='continuous'){
 const short=fx.spawn(def.id,{data:def.demo,loop:false,config:{lifetime:{durationMs:100}}}),long=fx.spawn(def.id,{data:def.demo,loop:false,config:{lifetime:{durationMs:9000}}});fx.update(500);
 item.consumer='runtime lifecycle (persistent visual time is independent)';item.changed=!short.alive&&long.alive;fx.stop(long);
 }items.push(item);if(!item.changed)dead.push(item);
 }catch(err){errors.push([def.id,spec.path,err.message])}}
 }catch(err){errors.push([def.id,err.message])}finally{if(h?.alive)fx.stop(h)}}
writeFileSync(new URL('../validation/parameter-audit.json',import.meta.url),JSON.stringify({items,dead,errors},null,2));console.log(JSON.stringify({count:items.length,dead,errors},null,2));

fx.dispose();if(dead.length||errors.length)process.exitCode=1;
