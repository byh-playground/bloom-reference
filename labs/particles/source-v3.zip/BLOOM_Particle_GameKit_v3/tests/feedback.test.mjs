import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {BloomEffects,NumberTransition,NumberLabelChannel,UiMotion,normalizeFeedbackData,formatNumber,resolveConfig,catalog,createPresentationAdapter} from '../bloom-effects.js';
import {PresentationEventQueue} from '../vendor/presentation-events.js';
function fixture(){const device={createPipeline(){return{}},createVertexBuffer(){return{}},deletePipeline(){},deleteVertexBuffer(){},uploadVertices(_,data){assert.ok(data.every(Number.isFinite));},draw(){}};return new BloomEffects({device});}
function sample(fx,h,t){fx.seek(h,t);fx.geometry.begin({width:800,height:600});fx.draw(h);const data=fx.geometry.data.slice(0,fx.geometry.n);assert.ok(data.every(Number.isFinite));return createHash('sha256').update(data).digest('hex');}
test('28종 추가 · 중복 ID 없음 · 46종 유지',()=>{assert.equal(catalog.length,74);assert.equal(new Set(catalog.map(e=>e.id)).size,74);assert.equal(catalog.filter(e=>e.family==='feedback').length,28);assert.equal(catalog.filter(e=>e.type==='combo').length,6);});
test('format: 부호 · 소수 · 천단위 · 단위 올림 · 작은 수 · 0',()=>{
 assert.equal(formatNumber(12345.67,{decimals:2}),'12,345.67');assert.equal(formatNumber(-10.5,{sign:'always',decimals:1}),'-10.5');assert.equal(formatNumber(20,{sign:'always'}),'+20');assert.equal(formatNumber(-0), '0');
 assert.equal(formatNumber(999999,{compact:true,decimals:1}),'1.0M');assert.equal(formatNumber(1250,{compact:true,decimals:1}),'1.3K');assert.equal(formatNumber(-.00002,{decimals:2}),'-2.00E-5');assert.equal(formatNumber(-.00002,{decimals:2,tiny:'zero'}),'0.00');assert.equal(formatNumber(0,{sign:'always'}),'+0');assert.equal(formatNumber(12,{prefix:'HP ',suffix:'%'}),'HP 12%');
 assert.throws(()=>formatNumber(Infinity));assert.throws(()=>formatNumber(1,{decimals:7}));assert.throws(()=>formatNumber(1,{tiny:'hide'}));
});
test('absolute-time transition · FPS 독립 · 일정 속도 · 지연',()=>{
 const t=new NumberTransition({from:100,to:0,durationMs:1000,delayMs:200,easing:'linear'});assert.equal(t.sample(199),100);assert.equal(t.sample(700),50);assert.equal(t.sample(1200),0);assert.equal(t.sample(9000),0);
 const a=new NumberTransition({from:-100,to:150,durationMs:1000}),b=new NumberTransition({from:-100,to:150,durationMs:1000});for(let i=0;i<50;i++)a.sample(i*7);assert.equal(a.sample(720),b.sample(720));
 assert.throws(()=>new NumberTransition({durationMs:0}));assert.throws(()=>new NumberTransition({easing:'garbage'}));
});
test('연속 retarget · 현재 표시값에서 이어짐 · 다른 인스턴스 격리',()=>{
 const fx=fixture(),h=fx.spawn('count_up',{data:{from:0,to:100},config:{transition:{durationMs:1000,delayMs:0,easing:'linear'}}}),other=fx.spawn('count_up',{data:{from:400,to:800}});
 fx.update(400);assert.equal(fx.values(h).value,40);fx.retarget(h,200,{durationMs:1000});assert.equal(fx.values(h).value,40);fx.update(500);assert.equal(fx.values(h).value,120);const old=fx.snapshot(h);assert.throws(()=>fx.retarget(h,Infinity));assert.deepEqual(fx.snapshot(h),old);assert.equal(fx.values(other).to,800);fx.dispose();
});
test('전환 snapshot · spawn 복원 · 역방향 seek 동일',()=>{
 const fx=fixture(),h=fx.spawn('digit_roll',{data:{from:998,to:1234},config:{transition:{durationMs:900,delayMs:0}}});fx.update(350);fx.retarget(h,-350);fx.update(240);const saved=fx.snapshot(h),b=fx.spawn(saved.effect,saved);assert.deepEqual(fx.values(h),fx.values(b));assert.equal(sample(fx,h,590),sample(fx,b,590));fx.dispose();
});
test('게임 data immutable · 잘못된 값/이벤트 거부 · failure atomic',()=>{
 const fx=fixture(),d={from:0,to:20,max:100,events:[{atMs:100,value:25}]},h=fx.spawn('resource_number',{data:d});d.events[0].value=999;assert.equal(fx.snapshot(h).data.events[0].value,25);assert.equal(fx.values(h).value,0);fx.update(200);assert.equal(fx.values(h).value,25);const prev=fx.snapshot(h);assert.throws(()=>fx.setData(h,{max:0}));assert.deepEqual(fx.snapshot(h),prev);
 for(const invalid of [{count:-1},{count:1.5},{to:NaN},{unrecognized:2},{events:[{atMs:20,value:2},{atMs:10,value:1}]},{from:1e308,events:[{atMs:0,value:1e308}]}])assert.throws(()=>normalizeFeedbackData(invalid));fx.dispose();
});
test('부호 전환/소수/단위 올림의 자릿수 롤링 · 모든 정점 finite',()=>{
 const fx=fixture();for(const[from,to]of [[998,1002],[1002,998],[-15,15],[-5,-100],[.125,.375],[999990,1001000],[1e30,1.5e30]])for(const f of [{decimals:0},{decimals:2},{decimals:1,compact:true}]){const h=fx.spawn('digit_roll',{clock:'external',data:{from,to},config:{format:f}});for(const t of [0,100,260,325,470,715,949,1200,1700])sample(fx,h,t);assert.equal(formatNumber(fx.values(h).value,f),formatNumber(to,f));fx.stop(h);}fx.dispose();
});
test('수입 채널: 시간 창 합산 · 표시 상한 · 실제 게임 자원 불변',()=>{
 const fx=fixture(),channel=new NumberLabelChannel(fx,{mergeGapMs:250,maxSpanMs:480,maxVisible:3}),wallet={value:1000};const emit=(key,value)=>channel.emit({key,value,position:{x:10,y:20}}),a=emit('mineral:1',25);channel.update(100);fx.update(100);assert.equal(emit('mineral:1',50),a);assert.equal(fx.values(a).value,75);
 channel.update(400);fx.update(400);const b=emit('mineral:1',25);assert.notEqual(a,b);assert.equal(a.alive,false);for(let i=0;i<1000;i++)emit('drop:'+i,1);assert.equal(fx.size,3);assert.equal(wallet.value,1000);assert.equal(channel.entries.size,3);channel.dispose();channel.dispose();assert.equal(fx.size,0);assert.throws(()=>emit('late',1));fx.dispose();
});
test('보상 조각 도착 이전 숫자 증가 없음 · 최종 목표값 정확',()=>{
 const fx=fixture(),h=fx.spawn('loot_transfer',{clock:'external',data:{from:100,to:220},config:{reward:{count:12,flightMs:900}}});fx.seek(h,1000);assert.equal(fx.values(h).value,100);fx.seek(h,1080);assert.equal(fx.values(h).value,110);fx.seek(h,2000);assert.equal(fx.values(h).value,220);fx.dispose();
});
test('DOM 재사용 UI motion · 불필요한 RAF/DOM 의존 없음 · 카드 폭만 변형',()=>{
 const spring=new UiMotion('button_spring');assert.equal(spring.sample(0).scaleX,.78);assert.equal(spring.sample(5000).scaleX,1);assert.equal(spring.sample(5000).opacity,1);
 const card=new UiMotion('card_reveal',{transition:{durationMs:1000,delayMs:0}});assert.equal(card.sample(500).scaleX,.02);assert.equal(card.sample(500).scaleY,1);assert.equal(card.sample(900).front,true);
 const deny=new UiMotion('denied_shake');assert.notEqual(deny.sample(100).x,0);assert.equal(deny.sample(5000).x,0);const out={};assert.equal(deny.sample(50,out),out);assert.throws(()=>new UiMotion('sparks'));
});
test('12종 지속표시: lifetime은 속도 배율이 아닌 종료 정책 · loop:false 자동 종료',()=>{
 const fx=fixture();for(const e of catalog.filter(e=>e.family==='feedback'&&e.type==='continuous')){const h=fx.spawn(e.id,{data:e.demo,loop:false,config:{lifetime:{durationMs:100}}});fx.update(101);assert.equal(h.state,'finished');}fx.dispose();
});
test('숫자 이벤트도 실제 GameKit queue: 중복과 롤백 취소',()=>{
 const fx=fixture(),q=new PresentationEventQueue({adapters:{vfx:createPresentationAdapter(fx)}}),ev={tick:10,sequence:1,entityId:'moa',generation:1,kind:'vfx',durationMs:1300,payload:{effect:'damage_number',data:{to:128},position:{x:10,y:20}}};q.emit(ev);assert.equal(fx.size,0);q.confirmThrough(10);q.emit(ev);assert.equal(fx.size,1);const h=[...fx.records.keys()][0];assert.equal(fx.values(h).value,128);q.update(1500);assert.equal(fx.size,0);q.emit({...ev,tick:20,policy:'speculative'});q.beginRollback(20);q.endRollback();assert.equal(fx.size,0);q.dispose();fx.dispose();
});

test('모양 설정 변경이 retarget의 수치 시간 계약을 덮어쓰지 않음',()=>{const fx=fixture(),h=fx.spawn('count_up',{data:{from:0,to:100}});fx.update(400);fx.retarget(h,200,{durationMs:500,delayMs:0});const before=fx.snapshot(h).transition;fx.configure(h,{appearance:{color:'#ffcc99'}});assert.deepEqual(fx.snapshot(h).transition,before);fx.dispose();});
