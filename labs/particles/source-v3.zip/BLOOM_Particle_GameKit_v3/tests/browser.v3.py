from pathlib import Path
import json,hashlib,os,time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'validation';OUT.mkdir(exist_ok=True)
HTML=ROOT/'BLOOM_Particle_Lab_v3_GameKit.html'
checks=[];errors=[];external=[]
def record(name,result=True):checks.append({'name':name,'result':result});print(time.strftime('%H:%M:%S'),name,flush=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=False,args=['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':1365,'height':1000},device_scale_factor=1,accept_downloads=True)
 def block(route):external.append(route.request.url);route.abort()
 context.route('http://**',block);context.route('https://**',block)
 page=context.new_page();page.set_default_timeout(10000);page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(HTML.read_text());page.wait_for_function('!!window.PARTICLE_LAB');page.evaluate('PARTICLE_LAB.state.paused=true')
 assert page.locator('.card').count()==28,page.locator('.card').count()
 for key,file in [('device','vendor/device.js'),('events','vendor/presentation-events.js'),('effects','bloom-effects.js'),('lab','lab.js')]:assert page.evaluate('(k)=>PARTICLE_LAB.sourceText(k)',key).encode()==(ROOT/file).read_bytes()
 record('오프라인 부팅 · 내장 모듈/원본 동일 · 신규 28종 첫 화면')
 page.locator('[data-category="numbers"]').click();assert page.locator('.card').count()==8
 page.locator('[data-category="all"]').click();assert page.locator('.card').count()==68
 page.locator('#search').fill('버드모리');assert page.locator('.card').count()>0
 page.locator('#search').fill('');page.locator('#newEffects').click();assert page.locator('.card').count()==28
 record('분류 · 전체 · 참고 게임 검색 · 신규 모아보기')
 counts=page.evaluate('''()=>{const L=PARTICLE_LAB;let cases=0,maxVertices=0;for(const e of BLOOM_SDK.catalog){L.open(e.id);for(const f of [.04,.2,.45,.7,.92]){L.seekMs(e.durationMs*f);const g=L.renderer;if(!g.data.subarray(0,g.n).every(Number.isFinite))throw Error(e.id+' NaN');if(L.getGLerror())throw Error(e.id+' GL');maxVertices=Math.max(maxVertices,g.n/9);cases++;}}return{effects:BLOOM_SDK.catalog.length,cases,maxVertices};}''')
 assert counts['cases']==370;record('74종 × 5시점 실제 WebGL 렌더',counts)
 if os.environ.get('BLOOM_CAPTURE')=='1':
  # Capture every new effect through the same visible inspector and GPU, not mock renderer.
  shots=OUT/'effect-crops';shots.mkdir(exist_ok=True)
  for e in page.evaluate('BLOOM_SDK.catalog.filter(x=>x.family==="feedback").map(x=>({id:x.id,duration:x.durationMs}))'):
   t={'critical_number':220,'damage_number':250,'health_trail':750,'digit_roll':665,'card_reveal':960,'loot_transfer':1050,'denied_shake':70,'button_spring':150}.get(e['id'],e['duration']*.4)
   page.evaluate('(p)=>{PARTICLE_LAB.open(p.id);PARTICLE_LAB.seekMs(p.t)}',{'id':e['id'],'t':t});page.locator('#inspectorStage').screenshot(path=str(shots/(e['id']+'.png')))
  record('신규28종 실제 렌더 스크린샷 보관')
 page.evaluate("PARTICLE_LAB.open('count_up');PARTICLE_LAB.seekMs(700)")
 page.locator('[data-value="from"]').fill('1250');page.locator('[data-value="to"]').fill('4321.25');page.locator('#applyData').click();page.evaluate('PARTICLE_LAB.seekMs(1500)')
 assert page.evaluate('PARTICLE_LAB.runtime.values(PARTICLE_LAB.state.inspector.handle).value')==4321.25
 page.locator('#numberFormat').select_option('decimal');page.locator('#numberEasing').select_option('linear')
 assert page.evaluate('PARTICLE_LAB.state.inspector.config.format.decimals')==1
 page.locator('#snapshotCompare').click()
 page.locator('#reverseValues').click();page.evaluate('PARTICLE_LAB.seekMs(450)')
 assert page.evaluate('PARTICLE_LAB.state.inspector.data.to')==1250
 page.locator('#snapshotCompare').click();page.evaluate("PARTICLE_LAB.nav('compare');PARTICLE_LAB.renderNow()")
 assert page.locator('.compare-card').count()==2
 assert page.evaluate('PARTICLE_LAB.views.map(v=>v.scene.data.to)')==[4321.25,1250]
 page.screenshot(path=str(OUT/'compare-desktop.png'))
 record('실제 숫자 입력 · 소수 형식 · 곡선 · 증감 반전 · 독립 A/B 비교')
 page.evaluate("PARTICLE_LAB.open('digit_roll');PARTICLE_LAB.seekMs(700)")
 page.locator('#dataJson').click();page.locator('#dataText').fill('{"from":-12.5,"to":1234.75,"max":10000}');page.locator('#dataApply').click()
 page.locator('#numberFormat').select_option('decimal');page.evaluate('PARTICLE_LAB.seekMs(520)')
 before=page.evaluate('PARTICLE_LAB.runtime.values(PARTICLE_LAB.state.inspector.handle).value');page.locator('[data-value="to"]').fill('2000');page.locator('#retargetValue').click();page.evaluate('PARTICLE_LAB.seekMs(0)')
 assert abs(page.evaluate('PARTICLE_LAB.runtime.values(PARTICLE_LAB.state.inspector.handle).value')-before)<1e-8
 page.locator('#dataJson').click();page.locator('#dataText').fill('{"max":0}');page.locator('#dataApply').click();assert page.locator('#dataError').inner_text();page.locator('#dataClose').click()
 page.locator('#editConfig').click();page.locator('#configJson').fill('{"unknown":1}');page.locator('#configApply').click();assert page.locator('#configError').inner_text();page.locator('#configClose').click()
 record('현재 표시값에서 새 목표 · data JSON 병합 · 잘못된 데이터/설정 거부')
 preset=page.evaluate('PARTICLE_LAB.capture(PARTICLE_LAB.state.inspector)');assert preset['version']==3 and preset['data']['to']==2000
 page.locator('#exportCode').click();assert 'data:' in page.locator('#usageCode').input_value()
 with page.expect_download() as dl:page.locator('#downloadRuntime').click()
 path=OUT/'exported-effects.js';dl.value.save_as(path);assert path.read_bytes()==(ROOT/'bloom-effects.js').read_bytes()
 with page.expect_download() as dl:page.locator('#downloadConfig').click()
 path=OUT/'exported-preset.json';dl.value.save_as(path);data=json.loads(path.read_text());assert data['data']['to']==2000 and data['config']['format']['decimals']==1
 with page.expect_download() as dl:page.locator('#downloadExample').click()
 path=ROOT/'examples'/'digit-roll-standalone.html';dl.value.save_as(path)
 page.locator('#exportClose').click()
 ex=context.new_page();ex.on('pageerror',lambda e:errors.append('standalone:'+str(e)));ex.set_content(path.read_text());ex.wait_for_function('!!window.BLOOM_EXAMPLE');ex.evaluate('BLOOM_EXAMPLE.seek(1800)')
 assert ex.evaluate('BLOOM_EXAMPLE.effects.values(BLOOM_EXAMPLE.handle).value')==2000
 assert ex.evaluate('BLOOM_EXAMPLE.device.gl.getError()')==0
 assert ex.locator('.sidepanel').count()==0;ex.close()
 record('추출 모듈/프리셋/독립 HTML · 입력값 보존 · 실제 별도 WebGL 실행')
 # Legacy module behavior/UI retention.
 page.evaluate("PARTICLE_LAB.open('sparks');PARTICLE_LAB.seekMs(420)")
 page.locator('#p-gravity').fill('0');page.locator('#p-gravity').dispatch_event('input');assert page.evaluate('PARTICLE_LAB.state.inspector.config.motion.gravityScale')==0
 page.locator('#editConfig').click();page.locator('#configJson').fill('{"appearance":{"scale":10},"motion":{"gravityScale":0}}');page.locator('#configApply').click();assert page.evaluate('PARTICLE_LAB.state.inspector.config.appearance.scale')==10
 page.evaluate("PARTICLE_LAB.open('combo_fireball');PARTICLE_LAB.seekMs(2800)")
 for el in page.locator('[data-layer]').all():el.uncheck()
 page.evaluate('PARTICLE_LAB.renderNow()');assert page.evaluate('PARTICLE_LAB.state.inspector.layers.every(x=>!x)')
 record('기존 효과 무중력/큰 설정 · 조합 레이어 끄기 회귀 검사')
 gpu=page.evaluate('''()=>{const S=BLOOM_SDK,d=PARTICLE_LAB.device,fx=new S.BloomEffects({device:d}),channel=new S.NumberLabelChannel(fx,{maxVisible:10});for(let i=0;i<1000;i++)channel.emit({key:'drop'+(i%30),value:25,position:{x:140+i%10*60,y:200}});d.beginFrame({width:1365,height:1000});fx.render({width:1365,height:1000});d.endFrame();if(d.gl.getError())throw Error('GPU burst');const peak=fx.size;channel.dispose();const q=new S.PresentationEventQueue({adapters:{vfx:S.createPresentationAdapter(fx)}}),ev={tick:10,sequence:1,entityId:'unit',generation:1,kind:'vfx',durationMs:1300,payload:{effect:'damage_number',data:{to:128},position:{x:300,y:200}}};q.emit(ev);q.confirmThrough(10);q.emit(ev);if(fx.size!==1)throw Error('duplicate');q.update(200);d.beginFrame({width:1365,height:1000});fx.render({width:1365,height:1000});d.endFrame();if(d.gl.getError())throw Error('GPU queue');q.update(2000);q.emit({...ev,tick:20,policy:'speculative'});q.beginRollback(20);q.endRollback();if(fx.size)throw Error('rollback');q.dispose();fx.dispose();return{burstVisuals:peak,pipelines:d.stats.pipelineCount,buffers:d.stats.bufferCount};}''')
 assert gpu['burstVisuals']==10 and gpu['pipelines']==1 and gpu['buffers']==1;record('1000회 수입 입력/표시10개 상한 · 실제 GameKit 숫자 이벤트 중복/롤백',gpu)
 page.evaluate('PARTICLE_LAB.renderNow();window.loss=PARTICLE_LAB.device.gl.getExtension("WEBGL_lose_context");loss.loseContext()');page.wait_for_function('PARTICLE_LAB.device.state==="lost"');page.evaluate('loss.restoreContext()');page.wait_for_function('PARTICLE_LAB.device.state==="ready"');page.evaluate('PARTICLE_LAB.renderNow()');assert page.evaluate('PARTICLE_LAB.getGLerror()')==0
 record('WebGL context loss → GameKit 원본 복구')
 for size in [{'width':390,'height':844},{'width':844,'height':390}]:
  c=browser.new_context(viewport=size,device_scale_factor=1,is_mobile=True,has_touch=True,accept_downloads=True);c.route('http://**',block);c.route('https://**',block)
  m=c.new_page();m.on('pageerror',lambda e:errors.append('mobile:'+str(e)));m.set_content(HTML.read_text());m.wait_for_function('!!window.PARTICLE_LAB');m.evaluate("PARTICLE_LAB.state.paused=true;PARTICLE_LAB.open('health_trail');PARTICLE_LAB.seekMs(700)")
  assert m.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
  rect=m.locator('#inspectorStage').bounding_box();m.touchscreen.tap(rect['x']+rect['width']*.55,rect['y']+rect['height']*.55)
  m.locator('[data-value="to"]').fill('25');m.locator('#applyData').click();m.evaluate('PARTICLE_LAB.seekMs(700)');assert m.evaluate('PARTICLE_LAB.state.inspector.data.to')==25
  m.screenshot(path=str(OUT/f"mobile-{size['width']}x{size['height']}.png"))
  m.locator('#exportCode').click();assert m.locator('#downloadRuntime').is_visible();assert m.evaluate('document.documentElement.scrollWidth<=innerWidth+1');assert m.evaluate('PARTICLE_LAB.getGLerror()')==0
  c.close();record('모바일 터치·수치 변경·내보내기 '+str(size))
 hud=context.new_page();hud.on('pageerror',lambda e:errors.append('hud:'+str(e)));hud.set_content((ROOT/'examples/ui-hud-standalone.html').read_text());hud.wait_for_function('!!window.BLOOM_HUD_EXAMPLE')
 hud.locator('#reward').click();hud.locator('#reward').click();hud.locator('#hit').click();hud.locator('#heal').click();hud.evaluate('BLOOM_HUD_EXAMPLE.render(900)')
 assert hud.evaluate('BLOOM_HUD_EXAMPLE.state.wallet')==1250
 assert hud.evaluate('BLOOM_HUD_EXAMPLE.state.hp')==97
 assert hud.locator('#wallet').inner_text()=='1,250'
 assert hud.evaluate('BLOOM_HUD_EXAMPLE.device.gl.getError()')==0
 hud.screenshot(path=str(OUT/'dom-hud-example.png'));hud.close();record('기존 DOM 버튼/지갑 · 실제 WebGL 피해/회복 · 같은 UI 모션 연결 예제')
 # Regenerate legacy standalone with exactly the final runtime, not an older bundled copy.
 page.evaluate("PARTICLE_LAB.open('sparks');PARTICLE_LAB.seekMs(400)")
 (ROOT/'examples/sparks-standalone.html').write_text(page.evaluate('PARTICLE_LAB.makeStandalone(PARTICLE_LAB.capture(PARTICLE_LAB.state.inspector))'))
 assert not errors,errors;assert not external,external
 report={'checks':checks,'pageErrors':errors,'externalRequests':external,'environment':{'browser':browser.version,'mode':'Xvfb headed Chromium / ANGLE SwiftShader / page.set_content','realPhone':False,'actualGameIntegration':False}}
 (OUT/'browser-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));browser.close()
