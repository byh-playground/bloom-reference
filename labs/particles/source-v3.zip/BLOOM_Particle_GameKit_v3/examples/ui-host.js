// Demonstration host, not either game's code. Only this host owns demo HP and wallet.
export function start(SDK){
 const {WebGLDevice,BloomEffects,NumberTransition,NumberLabelChannel,UiMotion,formatNumber}=SDK;
 const canvas=document.querySelector('canvas'),device=new WebGLDevice(canvas,{alpha:true,depth:false,stencil:false});
 const effects=new BloomEffects({device}),income=new NumberLabelChannel(effects,{maxVisible:10});
 const state={wallet:1200,hp:100,maxHp:100};let clock=0,last=0,raf=0,activeButton=null,pressedAt=0;
 const transition=new NumberTransition({from:state.wallet,to:state.wallet,durationMs:650,easing:'outCubic'});
 const motion=new UiMotion('button_spring'),pose={};
 const hp=effects.spawn('health_trail',{data:{from:100,to:100,max:100},position:{x:innerWidth/2,y:230}});
 const point=()=>({x:innerWidth/2,y:220});
 function press(button){if(activeButton)activeButton.style.transform='';activeButton=button;pressedAt=clock;}
 function reward(){state.wallet+=25;transition.retarget(state.wallet,clock);income.emit({key:'wallet',value:25,position:{x:innerWidth/2,y:330}});press(document.querySelector('#reward'));}
 function changeHP(delta){const before=state.hp;state.hp=Math.max(0,Math.min(state.maxHp,before+delta));const actual=state.hp-before;if(!actual)return;
  effects.setData(hp,{from:before,to:state.hp,max:state.maxHp},{restart:true});effects.spawn(actual<0?'damage_number':'healing_number',{position:{x:innerWidth/2,y:130},data:{to:Math.abs(actual)}});
  press(document.querySelector(actual<0?'#hit':'#heal'));
 }
 document.querySelector('#reward').onclick=reward;
 document.querySelector('#hit').onclick=()=>changeHP(-18);
 document.querySelector('#heal').onclick=()=>changeHP(15);
 function render(dt=0){clock+=dt;effects.update(dt);income.update(dt);
  const width=innerWidth,height=innerHeight,dpr=Math.min(devicePixelRatio||1,2);effects.setAnchors(hp,{position:point()});
  if(!device.gl.isContextLost()&&device.beginFrame({width:Math.round(width*dpr),height:Math.round(height*dpr),clearColor:[.04,.07,.09,1]})){effects.render({width,height});device.endFrame();}
  document.querySelector('#wallet').textContent=formatNumber(transition.sample(clock));document.querySelector('#hp').textContent=state.hp;
  if(activeButton){motion.sample(clock-pressedAt,pose);activeButton.style.transform=`scale(${pose.scaleX},${pose.scaleY})`;}
 }
 function frame(now){const dt=last?Math.min(200,now-last):0;last=now;render(dt);raf=requestAnimationFrame(frame);}
 render();raf=requestAnimationFrame(frame);
 window.BLOOM_HUD_EXAMPLE={state,effects,device,income,reward,changeHP,render,dispose(){cancelAnimationFrame(raf);income.dispose();effects.dispose();device.dispose();}};
}
