export function startLab(SDK, sourceText, makeStandalone) {
    const { WebGLDevice, BloomEffects, resolveConfig, parametersFor, timelineGroups, cloneData, patchAt, getPath, provenance } = SDK;
    const $ = selector => document.querySelector(selector), $$ = selector => [...document.querySelectorAll(selector)];
    const ALL = SDK.catalog.map(e => ({ ...e, duration: e.durationMs / 1000 })), EFFECTS = ALL.filter(e => e.type !== 'combo'), COMBOS = ALL.filter(e => e.type === 'combo'), CAT = SDK.categories, BY_ID = Object.fromEntries(ALL.map(e => [e.id, e]));
    const GROUND = new Set(['smash', 'debris', 'shockwave', 'fissure', 'splash', 'ripple', 'frost', 'ice', 'landing', 'poison']), TARGETED = new Set(['lightning', 'chain', 'laser', 'flamethrower', 'projectile', 'teleport', 'absorb','loot_transfer','direction_indicator']);
    function defaults(effect) { return resolveConfig(effect.id); }
    function specifics(id) { return parametersFor(id).map(p => p.key).filter(k => !['size', 'amount', 'duration', 'opacity'].includes(k)); }
    function point(x = 0, y = 0) { return { x, y }; }
    const device = new WebGLDevice($('#gfx'), { alpha: true, depth: false, stencil: false, powerPreference: 'high-performance' }), effects = new BloomEffects({ device }), R = effects.geometry;
    let raf = 0;
    const TAU = Math.PI * 2, clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x)), mix = (a, b, t) => a + (b - a) * t, fract = x => x - Math.floor(x), ease = x => 1 - Math.pow(1 - clamp(x), 3), smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); }, mod = (x, m) => ((x % m) + m) % m;
    function rand(i, seed = 2718) { let x = (Math.imul(i + 1, 1597334677) ^ Math.imul(seed | 0, 3812015801)) | 0; x = Math.imul(x ^ (x >>> 16), 2246822507); x = Math.imul(x ^ (x >>> 13), 3266489909); return ((x ^ (x >>> 16)) >>> 0) / 4294967296; }
    const hexCache = new Map();
    function rgb(hex) { if (Array.isArray(hex))
        return hex; if (hexCache.has(hex))
        return hexCache.get(hex); const a = [parseInt(hex.slice(1, 3), 16) / 255, parseInt(hex.slice(3, 5), 16) / 255, parseInt(hex.slice(5, 7), 16) / 255]; hexCache.set(hex, a); return a; }
    function blend(a, b, t) { a = rgb(a); b = rgb(b); return [a[0] * (1 - t) + b[0] * t, a[1] * (1 - t) + b[1] * t, a[2] * (1 - t) + b[2] * t]; }
    function character(x, y, s = 1, color = '#b8c8d0', a = 1, pose = 0) { R.scope(x, y, s, () => { R.disc(0, -39, 7, color, a); R.line(0, -31, 0, -13, 4, color, a); R.line(0, -13, -9 + pose * 3, 0, 3.5, color, a); R.line(0, -13, 9 + pose * 3, 0, 3.5, color, a); R.line(0, -26, -11, -15 - pose * 6, 3, color, a); R.line(0, -26, 11, -15 + pose * 6, 3, color, a); }); }
    const BODY = [];
    for (let y = -47; y < 0; y += 4)
        for (let x = -15; x <= 15; x += 4) {
            if ((x * x + (y + 40) ** 2 < 50) || (Math.abs(x) < 4 && y > -33 && y < -12) || (y > -27 && y < -12 && Math.abs(Math.abs(x) - (y + 28) * .64) < 3) || (y >= -14 && Math.abs(Math.abs(x) - (y + 14) * .7) < 3))
                BODY.push([x, y]);
        }
    const specimen = { cells: BODY, bounds: { minY: -48, maxY: 12 }, draw(renderer, { x, y, scale, color, alpha, pose }) { character(x, y, scale, color, alpha, pose); } };
    const previewHooks = { target(renderer, { x, y, radius: r = 13, alpha: a = .6 }) { renderer.ring(x, y, r, .8, '#829eab', a, 1, 0, TAU, 28); renderer.line(x - r - 5, y, x - r + 4, y, 1, '#92abb6', a); renderer.line(x + r - 4, y, x + r + 5, y, 1, '#92abb6', a); renderer.line(x, y - r - 5, x, y - r + 4, 1, '#92abb6', a); renderer.line(x, y + r - 4, x, y + r + 5, 1, '#92abb6', a); renderer.disc(x, y, 2, '#b7cfdb', a); }, ground(renderer, { y = 48 }) { renderer.line(-135, y, 135, y, .7, '#59717c', .3); renderer.ring(0, y, 24, .6, '#78948b', .3, .28); } };
    function mergeUI(target, patch) { for (const [k, v] of Object.entries(patch)) {
        if (['__proto__', 'prototype', 'constructor'].includes(k))
            throw Error('잘못된 키');
        if (v && typeof v === 'object' && !Array.isArray(v)) {
            if (!target[k])
                target[k] = {};
            mergeUI(target[k], v);
        }
        else
            target[k] = v;
    } return target; }
    function applyConfig(s, patch) { const ratio = s.time / duration(s); s.config = effects.configure(s.handle, patch); s.time = ratio * duration(s); syncControls(); }
    function replaceConfig(s, config) { const ratio = s.time / duration(s); effects.replace(s.handle, s.effect.id, { config, data:s.data, clock: 'external', loop: s.effect.type === 'continuous', subject: specimen, preview: previewHooks }); s.config = effects.getConfig(s.handle); s.time = ratio * duration(s); syncControls(); }
    function previewCombination(s, t) { const a = s.source, b = s.target, c = s.config.appearance.color; previewHooks.ground(R, { y: 40 }); if (s.effect.id === 'combo_absorb') {
        character(a.x, a.y + 40, .85, c, .45);
        if (t < .4)
            character(b.x, b.y + 40, .9, '#b9c5ca', .55);
    }
    else {
        character(a.x, a.y + 40, .85, c, .45);
        if (s.effect.id === 'combo_shield')
            character(b.x, b.y + 40, .88, '#b9c5ca', .55);
        else
            previewHooks.target(R, { x: b.x, y: b.y, radius: 15, alpha: .25 });
    } }
    function renderFrame(dt = 0) {
        // A loss may be visible to GL before the DOM loss event reaches the device.
        if (device.gl.isContextLost())
            return;
        const dpr = Math.min(devicePixelRatio || 1, 2);
        if (!device.beginFrame({ width: Math.max(1, Math.round(innerWidth * dpr)), height: Math.max(1, Math.round(innerHeight * dpr)), clearColor: [0, 0, 0, 0] }))
            return;
        R.resetStats();
        try {
            for (const v of views) {
                const rect = v.el.getBoundingClientRect();
                if (rect.bottom <= 0 || rect.top >= innerHeight || rect.right <= 0 || rect.left >= innerWidth || rect.width <= 0 || rect.height <= 0)
                    continue;
                v.rect = rect;
                if (dt)
                    updateScene(v.scene, dt);
                renderScene(v.scene, rect);
            }
        }
        finally {
            device.endFrame();
        }
    }
    function downloadText(name, text, type = 'text/javascript') { const url = URL.createObjectURL(new Blob([text], { type })), a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 2000); }
    async function copyText(text) { try {
        await navigator.clipboard.writeText(text);
        toast('복사했어요.');
    }
    catch {
        const area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.append(area);
        area.select();
        const ok = document.execCommand('copy');
        area.remove();
        toast(ok ? '복사했어요.' : '복사 권한이 없어요. 텍스트를 선택하거나 파일로 저장하세요.');
    } }
    function configDialog(s) { dialog('<h2 id="dialogTitle">컨피그 JSON 직접 편집</h2><p>현재 값 전체 또는 부분 객체를 입력하세요. 예: <code>{"motion":{"gravityScale":0}}</code>. 생략한 항목은 현재 값이 유지됩니다. 조합은 <code>timeline.tracks</code>를 여기에서 수정합니다. 배열은 전체 교체됩니다.</p><textarea id="configJson" spellcheck="false" aria-label="계층형 컨피그">' + safeText(JSON.stringify(s.config, null, 2)) + '</textarea><div class="error" id="configError"></div><div class="dialog-actions"><button id="configClose">닫기</button><button id="configCopy">복사</button><button class="primary" id="configApply">실제 효과에 적용</button></div>'); $('#configClose').onclick = closeDialog; $('#configCopy').onclick = () => copyText($('#configJson').value); $('#configApply').onclick = () => { try {
        const config = resolveConfig(s.effect.id, s.config, JSON.parse($('#configJson').value));
        applyConfig(s, config);
        closeDialog();
        openInspector(s.effect.id, capture(s));
        toast('실행 인스턴스에 적용했어요.');
    }
    catch (error) {
        $('#configError').textContent = error.message;
    } }; }
    function useCode(s) { const config = JSON.stringify(s.config, null, 2); return `import { BloomEffects } from './bloom-effects.js';\n\n// device: 게임이 이미 생성한 bloom-gamekit WebGLDevice.\n// 새 캔버스나 두 번째 컨텍스트를 만들지 않습니다.\nconst effects = new BloomEffects({ device });\nconst handle = effects.spawn('${s.effect.id}', {\n  position: { x: 320, y: 180 },\n  source: { x: 227, y: 180 },\n  target: { x: 403, y: 180 },\n  seed: ${s.seed},\n  data: ${JSON.stringify(s.data)},\n  config: ${config}\n});\n\n// 게임의 표현 루프에서 호출 (밀리초).\neffects.update(deltaMs);\n// 기존 device.beginFrame(...)과 device.endFrame() 사이에:\neffects.render({ width: cssWidth, height: cssHeight });\n// 카메라가 필요하면 transform 또는 project(x, y, out)를 전달합니다.\n\n// 부착 대상·실제 경로는 setAnchors(handle, ...)로 갱신.\n// 유한 효과는 자동 종료. 지속 효과는 effects.stop(handle).\n// 씬 정리: effects.dispose(); device는 유지됩니다.\n// 디졸브·잔상: spawn에 게임 소유 subject.draw/cells를 전달합니다.\n`; }
    function exportDialog(s) { dialog('<h2 id="dialogTitle">게임에 가져가기</h2><p><b>GameKit WebGLDevice → BloomEffects → 같은 컨피그.</b><br>연구소 화면 없이 쓰는 ESM과, 그 코드로 실행되는 독립 예제를 추출합니다.</p><div class="export-grid"><button id="downloadRuntime" class="primary">이펙트 모듈 .js</button><button id="downloadExample" class="primary">현재 효과 독립 HTML</button><button id="downloadConfig">현재 프리셋 .json</button><button id="copyUsage">사용 코드 복사</button><button id="downloadDevice">GameKit device 원본</button><button id="downloadEvents">GameKit events 원본</button></div><details><summary>실제 호출 코드</summary><textarea readonly id="usageCode" spellcheck="false" aria-label="사용 코드">' + safeText(useCode(s)) + '</textarea></details><p class="muted">이미 GameKit을 쓰는 게임에는 이펙트 모듈만 추가합니다. 기존 WebGLDevice·카메라·시간·이벤트를 연결하세요. 샘플 캐릭터는 이식 대상이 아니며, 실제 유닛 도형은 게임이 제공합니다.<br>GameKit 원본 커밋 <code>421e041</code> · 외부 통신 없음 · 소스 저장소 변경 없음</p><div class="dialog-actions"><button id="exportClose">닫기</button></div>'); $('#exportClose').onclick = closeDialog; $('#copyUsage').onclick = () => copyText(useCode(s)); $('#downloadRuntime').onclick = () => downloadText('bloom-effects.js', sourceText('effects')); $('#downloadDevice').onclick = () => downloadText('device.js', sourceText('device')); $('#downloadEvents').onclick = () => downloadText('presentation-events.js', sourceText('events')); $('#downloadConfig').onclick = () => downloadText(s.effect.id + '.json', JSON.stringify(capture(s), null, 2), 'application/json'); $('#downloadExample').onclick = () => downloadText('BLOOM_' + s.effect.id + '_standalone.html', makeStandalone(capture(s)), 'text/html'); }
    const state = { tab: 'atlas', category: 'new', query: '', bg: 'dark', size: 'normal', paused: false, speed: 1, compare: [], presets: [], inspector: null, returnTab: 'atlas', seed: 2718, compareTime: 0 };
    const sceneCache = new Map();
    let views = [], lastTime = 0, frames = 0, fpsTime = 0, fps = 0, drawStats = {};
    let toastTimer;
    function toast(text) { $('#toast').textContent = text; $('#toast').classList.remove('hidden'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').classList.add('hidden'), 2600); }
    function safeText(v) { return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function uid() { return Date.now().toString(36) + '-' + Math.floor(Math.random() * 1e7).toString(36); }
    function createScene(effect, kind = 'gallery', config) {
        const s = { effect, kind, config: defaults(effect), seed: state.seed, time: kind === 'gallery' ? .15 + rand(effect.index, 2026) * Math.min(effect.duration * .6, .9) : 0, paused: false, loop: true, source: point(-93, 0), target: point(83, effect.id === 'combo_ice' ? 40 : 0), origin: point(0, GROUND.has(effect.id) ? 30 : 0), actor: point(-50, 32), history: [], interacted: false, layers: [true, true, true, true], hitAngle: -.55, showGuides: effect.family!=='feedback', showReference: false, zoom: 1, feedback: { shake: false, flash: false, stop: false, punch: false }, stopRemaining: 0, cycle: 0, triggered: new Set() };
        s.data=cloneData(effect.demo||{});
        s.handle = effects.spawn(effect.id, { data:s.data, config, seed: s.seed, clock: 'external', loop: effect.type === 'continuous', subject: specimen, preview: previewHooks });
        s.config = effects.getConfig(s.handle);
        return s;
    }
    function duration(s) { return s.config.lifetime.durationMs / 1000; }
    function elapsed(s) { return s.time + (s.effect.type === 'continuous' && s.kind === 'inspector' ? s.cycle * duration(s) : 0); }
    function timelineEnd(s) { return s.effect.type === 'continuous' && s.kind === 'inspector' ? (s.cycle + 1) * duration(s) : duration(s); }
    function setElapsed(s, t) {
        const d = duration(s);
        if (s.effect.type === 'continuous' && s.kind === 'inspector') {
            t = clamp(t, 0, 86400);
            s.cycle = Math.max(0, Math.ceil(t / d) - 1);
            s.time = t - s.cycle * d;
        }
        else {
            s.cycle = 0;
            s.time = clamp(t, 0, d);
        }
    }
    function galleryScene(e) {
        if (!sceneCache.has(e.id))
            sceneCache.set(e.id, createScene(e));
        return sceneCache.get(e.id);
    }
    function capture(s, name) { return { schema: 'bloom-particle-preset', version: 3, data:cloneData(s.data), id: uid(), name: name || s.effect.name + ' · 실험값', effect: s.effect.id, config: cloneData(s.config), seed: s.seed, anchors: { source: { ...s.source }, target: { ...s.target }, origin: { ...s.origin }, hitAngle: s.hitAngle }, layers: [...s.layers], savedAt: new Date().toISOString() }; }
    function restore(data, kind = 'inspector') {
        const s = createScene(BY_ID[data.effect], kind, data.config);
        s.seed = data.seed;
        if(data.data){s.data=cloneData(data.data);effects.setData(s.handle,s.data,{restart:true});}
        if (data.anchors) {
            for (let k of ['source', 'target', 'origin'])
                if (data.anchors[k])
                    s[k] = { ...data.anchors[k] };
            s.hitAngle = data.anchors.hitAngle ?? -.55;
        }
        if (data.layers)
            s.layers = [...data.layers];
        return s;
    }
    function validatePreset(raw) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw))
            throw Error('프리셋 JSON 객체가 필요합니다.');
        if (raw.schema !== 'bloom-particle-preset' || ![1,2,3].includes(raw.version))
            throw Error('파티클 연구소 프리셋 v1·v2·v3가 아닙니다.');
        const effect = BY_ID[raw.effect];
        if (!effect)
            throw Error('알 수 없는 효과 ID입니다.');
        let config = raw.config;
        if (raw.version === 1) {
            config = {};
            for (const spec of parametersFor(effect.id)) {
                let value = raw.config?.[spec.key];
                if (value !== undefined) {
                    if (spec.key === 'duration')
                        value *= effect.durationMs;
                    mergeUI(config, patchAt(spec.path, value));
                }
            }
            for (const key of ['color', 'glow'])
                if (raw.config?.[key] !== undefined && resolveConfig(effect.id).appearance[key] !== undefined)
                    mergeUI(config, { appearance: { [key]: raw.config[key] } });
        }
        const clean = { schema: 'bloom-particle-preset', version: 3, data:SDK.normalizeFeedbackData(raw.data||effect.demo||{}), id: uid(), name: String(raw.name || effect.name).slice(0, 80), effect: effect.id, config: resolveConfig(effect.id, config), seed: raw.seed ?? 2718, savedAt: new Date().toISOString() };
        if (!Number.isSafeInteger(clean.seed) || clean.seed < 0 || clean.seed > 4294967295)
            throw Error('난수는 uint32 정수여야 합니다.');
        if (raw.anchors) {
            clean.anchors = {};
            for (const k of ['source', 'target', 'origin'])
                if (raw.anchors[k] !== undefined) {
                    const v = raw.anchors[k];
                    if (!v || !Number.isFinite(v.x) || !Number.isFinite(v.y))
                        throw Error(k + ' 좌표는 유한수여야 합니다.');
                    clean.anchors[k] = { x: v.x, y: v.y };
                }
            if (raw.anchors.hitAngle !== undefined) {
                if (!Number.isFinite(raw.anchors.hitAngle))
                    throw Error('hitAngle은 유한수입니다.');
                clean.anchors.hitAngle = raw.anchors.hitAngle;
            }
        }
        if (raw.layers !== undefined) {
            if (!Array.isArray(raw.layers) || raw.layers.length !== 4 || raw.layers.some(v => typeof v !== 'boolean'))
                throw Error('layers는 boolean 4개 배열입니다.');
            clean.layers = raw.layers.slice();
        }
        if (raw.version === 1)
            toast('v1 값을 v2 계층형 설정으로 변환했어요. 미사용 항목은 제외됩니다.');
        return clean;
    }
    let persistentStorage = true;
    function loadStorage() {
        try {
            const raw = JSON.parse(localStorage.getItem('bloom-particle-lab-presets-v2') || '[]');
            if (Array.isArray(raw))
                for (const x of raw.slice(0, 100)) {
                    try {
                        state.presets.push(validatePreset(x));
                    }
                    catch (e) { }
                }
        }
        catch (e) {
            persistentStorage = false;
        }
    }
    function persist() {
        try {
            localStorage.setItem('bloom-particle-lab-presets-v2', JSON.stringify(state.presets));
            return true;
        }
        catch (e) {
            persistentStorage = false;
            toast('브라우저 저장이 제한되어 있어요. JSON 내보내기로 보관해 주세요.');
            return false;
        }
    }
    loadStorage();
    function setViews() { const next = $$('.stage[data-scene]').map(el => ({ el, scene: el._scene, rect: null })).filter(v => v.scene); for (const v of views)
        if (v.scene.kind !== 'gallery' && !next.some(n => n.scene === v.scene) && v.scene.handle.alive)
            effects.stop(v.scene.handle); views = next; }
    function updateTabs() {
        for (const b of $$('.tab'))
            b.classList.toggle('active', b.dataset.tab === state.tab);
        $('#compareCount').textContent = state.compare.length;
        $('#trayCount').textContent = state.compare.length;
        $('#compareTray').classList.toggle('hidden', !state.compare.length || state.tab === 'compare' || !!state.inspector);
        $('#trayChips').innerHTML = state.compare.map((x, i) => '<span class="chip">' + safeText(x.name) + '<button data-remove-slot="' + i + '" aria-label="' + safeText(x.name) + ' 비교 제거">×</button></span>').join('');
        $('#homeHead').classList.toggle('hidden', !!state.inspector);
        $('#browseControls').classList.toggle('hidden', !!state.inspector || ['compare', 'presets'].includes(state.tab));
    }
    function renderFilters() { const active = state.tab === 'atlas'; $('#filters').classList.toggle('hidden', !active); $('#filters').innerHTML = [['new','신규 28종'],['all', '전체'], ...CAT].map(([k, n]) => '<button class="filter ' + (state.category === k ? 'active' : '') + '" data-category="' + k + '">' + n + '<small>' + (k==='new'?28:k==='all'?EFFECTS.length:EFFECTS.filter(e=>e.cat===k).length) + '</small></button>').join(''); }
    function renderGallery() {
        state.inspector = null;
        updateTabs();
        renderFilters();
        const source = state.tab === 'combos' ? COMBOS : EFFECTS;
        const q = state.query.toLocaleLowerCase();
        const filtered = source.filter(e => (state.tab === 'combos' || state.category === 'all' || (state.category==='new'&&e.family==='feedback') || e.cat === state.category) && (!q || (e.id+' '+(e.reference||'')+' '+e.name + ' ' + e.sub + ' ' + e.tech + ' ' + e.parts.join(' ')).toLocaleLowerCase().includes(q)));
        const heading = state.tab === 'combos' ? '기본 효과를 연결한 6개의 공격' : (state.category==='new'?'수치·게이지·UI · 새로 추가한 28종':'형태와 움직임으로 구분한 효과');
        $('#main').innerHTML = '<div class="section-label"><strong>' + heading + ' <span class="muted mono">/ ' + filtered.length + '</span></strong><span>카드를 눌러 확대 실험 ↗</span></div><div id="effectGrid" class="grid ' + (state.size === 'normal' ? '' : state.size) + '"></div>' + (filtered.length ? '' : '<div class="empty">검색 결과가 없어요. 다른 이름이나 용도로 찾아보세요.</div>');
        const grid = $('#effectGrid');
        for (const e of filtered) {
            const scene = galleryScene(e), card = document.createElement('article');
            card.className = 'card';
            card.dataset.effect = e.id;
            card.innerHTML = '<div class="stage" data-scene="' + e.id + '" role="button" tabindex="0" aria-label="' + e.name + ' 확대 실험"><span class="stage-label mono">' + (e.cat === 'combo' ? 'C' : 'F') + ' ' + String(e.cat === 'combo' ? e.index - 40 : e.index).padStart(2, '0') + '</span><span class="stage-tag">' + (e.type === 'continuous' ? '지속' : e.type === 'combo' ? '조합' : '단발') + '</span><span class="stage-foot">' + e.tech + '</span><span class="open-hint">확대 실험 ↗</span></div><div class="card-footer"><div><h3>' + e.name + '</h3><p>' + e.sub + '</p></div><div class="card-actions"><button data-pause="' + e.id + '" title="이 카드 재생·정지" aria-label="' + e.name + ' 재생·정지">' + (scene.paused ? '▶' : 'Ⅱ') + '</button><button data-compare="' + e.id + '" title="비교에 보관" aria-label="' + e.name + ' 비교에 보관">＋</button></div></div>';
            const stage = card.querySelector('.stage');
            stage._scene = scene;
            stage.addEventListener('click', () => openInspector(e.id));
            stage.addEventListener('keydown', ev => {
                if (ev.key === 'Enter' || ev.key === ' ') {
                    ev.preventDefault();
                    openInspector(e.id);
                }
            });
            grid.appendChild(card);
        }
        setViews();
        updateComparisonButtons();
    }
    function nav(tab) {
        state.inspector = null;
        state.tab = tab;
        state.query = '';
        $('#search').value = '';
        if (tab === 'compare')
            renderCompare();
        else if (tab === 'presets')
            renderPresets();
        else
            renderGallery();
        scrollTo({ top: 0, behavior: 'instant' });
    }
    function updateComparisonButtons() {
        for (const b of $$('[data-compare]'))
            b.classList.toggle('selected', state.compare.some(p => p.effect === b.dataset.compare));
    }
    function addCompare(s) {
        if (state.compare.length >= 4) {
            toast('비교는 최대 4개예요. 기존 슬롯을 비운 뒤 추가해 주세요.');
            return;
        }
        let n = state.compare.filter(x => x.effect === s.effect.id).length;
        const cap = capture(s, s.effect.name + (n ? ' · ' + String.fromCharCode(65 + n) : ' · A'));
        state.compare.push(cap);
        updateTabs();
        updateComparisonButtons();
        toast(cap.name + '를 비교에 보관했어요.');
    }

    function installDataPanel(s){
        if(s.effect.family!=='feedback')return;
        const box=document.createElement('section');box.className='data-panel';
        const keys=['digit_roll','delta_number','loot_transfer'].includes(s.effect.id)?['from','to']:s.effect.id==='shield_gauge'?['from','to','max','secondary']:
          s.effect.id==='xp_level'?['from','to','max','count']:
          s.effect.id==='buff_stack'?['from','to','max','count']:
          ['count_up','health_trail','radial_cooldown','segmented_gauge','capture_meter','loot_transfer','attack_warning'].includes(s.effect.id)?['from','to','max']:['to'];
        const labels={from:'시작 값',to:'목표·표시 값',max:'최대·임계값',secondary:'현재 체력',count:'레벨·스택'};
        box.innerHTML='<div class="data-title">게임 입력 데이터 <span class="mono">DATA ≠ CONFIG</span></div><p>게임 값은 아래에서, 움직임·모양은 컨피그에서 바꿉니다.</p><div class="data-fields">'+keys.map(k=>'<label>'+labels[k]+'<input type="number" step="any" data-value="'+k+'" value="'+(s.data[k]??0)+'"></label>').join('')+'</div><div class="panel-buttons"><button id="applyData" class="primary">입력값으로 재생</button><button id="dataJson">데이터 JSON</button>'+(s.config.transition?'<button id="retargetValue">현재 값 → 새 목표</button><button id="reverseValues">증가 ↔ 감소</button>':'')+'</div><div class="data-error" role="status"></div><p class="data-reference">참고: '+safeText(s.effect.reference)+'</p>';
        $('.sidepanel').prepend(box);
        const error=box.querySelector('.data-error');
        const scheduleNote=document.createElement('p');box.insertBefore(scheduleNote,box.querySelector('.data-fields'));
        const showSchedule=()=>{const n=s.data.events?.length||0;scheduleNote.hidden=!n;scheduleNote.textContent=n?'시연 이벤트 '+n+'개 · 합계 '+SDK.formatNumber((s.data.from||0)+s.data.events.reduce((v,e)=>v+e.value,0))+' / 수치 입력 적용 시 단일 값 표시로 전환됩니다.':'';};showSchedule();
        const patch=()=>{const p={};for(const el of box.querySelectorAll('[data-value]')){if(el.value.trim()==='')throw Error('빈 수치는 사용할 수 없습니다.');p[el.dataset.value]=Number(el.value);}return p;};
        const apply=(value)=>{const clean=SDK.normalizeFeedbackData(value,s.data);effects.setData(s.handle,clean,{restart:true});s.data=cloneData(clean);showSchedule();replay(s);error.textContent='입력값 적용됨';};
        $('#applyData').onclick=()=>{try{const p=patch();if(s.data.events?.length)p.events=[];apply(p);}catch(e){error.textContent=e.message;}};
        if($('#retargetValue'))$('#retargetValue').onclick=()=>{try{const current=effects.values(s.handle).value;apply({...patch(),from:current,events:[]});box.querySelector('[data-value="from"]').value=current;}catch(e){error.textContent=e.message;}};
        if($('#reverseValues'))$('#reverseValues').onclick=()=>{try{const p=patch();[p.from,p.to]=[p.to,p.from];apply(p);for(const el of box.querySelectorAll('[data-value]'))el.value=s.data[el.dataset.value];}catch(e){error.textContent=e.message;}};
        $('#dataJson').onclick=()=>{
            dialog('<h2 id="dialogTitle">게임 데이터 · JSON</h2><p><code>from / to / max</code>는 실제 값입니다. <code>events:[{atMs:100,value:25}]</code>는 합산·연타 시연의 입력 시간표입니다. 실제 게임은 이벤트가 확정될 때 값을 전달하세요.</p><textarea id="dataText">'+safeText(JSON.stringify(s.data,null,2))+'</textarea><div id="dataError" class="error"></div><div class="dialog-actions"><button id="dataClose">닫기</button><button id="dataApply" class="primary">적용·재생</button></div>');
            $('#dataClose').onclick=closeDialog;$('#dataApply').onclick=()=>{try{apply(JSON.parse($('#dataText').value));for(const el of box.querySelectorAll('[data-value]'))el.value=s.data[el.dataset.value];closeDialog();}catch(e){$('#dataError').textContent=e.message;}};
        };
        if(s.config.transition?.easing){const label=document.createElement('label');label.className='data-format';label.innerHTML='전환 곡선 <select id="numberEasing"><option value="linear">일정 속도</option><option value="outCubic">끝에서 감속</option><option value="inOutCubic">가속 → 감속</option></select>';box.insertBefore(label,box.querySelector('.data-reference'));$('#numberEasing').value=s.config.transition.easing;$('#numberEasing').onchange=e=>applyConfig(s,{transition:{easing:e.target.value}});}
        if(s.config.format){
            const format=document.createElement('div');format.className='data-format';
            format.innerHTML='<label>표시 형식 <select id="numberFormat"><option value="integer">정수 · 1,234</option><option value="decimal">소수 · 1,234.5</option><option value="signed">부호 · +1,234</option><option value="compact">축약 · 1.2K</option></select></label>';
            box.insertBefore(format,box.querySelector('.data-reference'));
            $('#numberFormat').value=s.config.format.compact?'compact':s.config.format.decimals?'decimal':s.config.format.sign==='always'?'signed':'integer';
            $('#numberFormat').onchange=e=>{const mode=e.target.value;applyConfig(s,{format:{decimals:mode==='decimal'||mode==='compact'?1:0,compact:mode==='compact',sign:mode==='signed'?'always':'auto'}});};
        }
    }

    function rangeHTML(k, s) { const spec = parametersFor(s.effect.id).find(x => x.key === k); if (!spec)
        return ''; const v = getPath(s.config, spec.path); return '<div class="param"><label class="param-label" for="p-' + k + '"><span>' + spec.label + '</span><output id="o-' + k + '">' + formatParam(k, v) + '</output></label><input type="range" id="p-' + k + '" data-param="' + k + '" min="' + Math.min(spec.min, v) + '" max="' + Math.max(spec.max, v) + '" step="' + spec.step + '" value="' + v + '"><small class="config-path mono">' + spec.path + '</small></div>'; }
    function formatParam(k,v){if(k==='opacity')return Math.round(v*100)+'%';const spec=state.inspector?parametersFor(state.inspector.effect.id).find(p=>p.key===k):null;return Number(v.toFixed(2))+(spec?.unit?' '+spec.unit:'');}
    function openInspector(id, preset = null) {
        state.returnTab = state.inspector ? state.returnTab : state.tab;
        state.inspector = preset ? restore(preset) : createScene(BY_ID[id], 'inspector');
        const s = state.inspector, e = s.effect;
        updateTabs();
        const isCombo = e.type === 'combo';
        const help = isCombo ? '민트 점: 시작점 · 주황 점: 표적 — 두 점을 끌어서 이동' : TARGETED.has(e.id) ? '민트 점: 시작점 · 주황 점: 끝점 — 드래그로 경로 변경' : e.id === 'dash' ? '방향키 / WASD 또는 화면 드래그로 이동' : e.id === 'shield' ? '보호막을 클릭·터치하면 맞은 표면에서 파동 발생' : '화면을 클릭·터치하여 발생 위치 변경 · 드래그 가능';
        const cat = isCombo ? '조합 시험장' : CAT.find(c => c[0] === e.cat)[1];
        $('#main').innerHTML = '<div class="workspace-head"><div><div class="breadcrumb"><button class="ghost small" id="backBtn">← ' + (state.returnTab === 'compare' ? '비교로' : state.returnTab === 'presets' ? '프리셋으로' : '도감으로') + '</button><span> / ' + cat + '</span></div><h2>' + e.name + '</h2></div><div class="actions"><button id="prevEffect" class="small" title="이전 효과">←</button> <button id="nextEffect" class="small" title="다음 효과">→</button> <button id="snapshotCompare" class="small primary">＋ 현재 값 비교 보관</button></div></div><div class="workspace-layout"><div class="work-main"><div class="stage inspector-stage" id="inspectorStage" data-scene="inspector" tabindex="0" role="application" aria-label="' + e.name + ' 조작 실험장"><div class="work-top"><span><i class="live-dot"></i><span id="sceneStatus">재생 중</span> <span class="mono"> / SEED <span id="seedLabel">' + s.seed + '</span></span></span><span class="mono" id="viewStats">동일 렌더러</span></div><div class="anchor-hint"><span>' + help + '</span><span id="scaleHint">기본 관찰 크기</span></div></div><div class="playback"><button class="icon" id="scenePlay" title="재생·정지 (Space)">Ⅱ</button><button class="icon" id="sceneRestart" title="같은 난수로 다시 재생 (R)">↺</button><button class="icon" id="sceneStep" title="한 프레임 진행 (.)">▹</button><input type="range" id="timeline" min="0" max="1000" step="1" value="0" aria-label="재생 시간"><span class="mono time-label" id="timeLabel">0.00 / ' + duration(s).toFixed(2) + 's</span><select id="sceneSpeed" class="speed-select" aria-label="실험 재생 속도"><option value=".25">0.25×</option><option value=".5">0.5×</option><option value="1">1×</option><option value="2">2×</option></select><label><input id="sceneLoop" type="checkbox" checked>반복</label></div><div class="description"><strong>' + e.sub + '</strong><br>' + e.desc + '</div><div class="anatomy"><div class="anatomy-head">' + (isCombo ? '레이어 / 발동 구간 — 체크를 끄면 해당 부분만 숨김' : '효과 해부 / 구성 요소') + '</div>' + (isCombo ? e.parts.map((name, i) => { const group = timelineGroups(e.id, s.config)[i], times = [group.startMs / 1000, group.endMs / 1000]; return '<label class="layer"><input type="checkbox" data-layer="' + i + '" checked><span>' + name + '</span><span class="layer-bar" title="' + times[0] + '–' + times[1] + '초"><i style="left:' + (times[0] / e.duration * 100) + '%;width:' + ((times[1] - times[0]) / e.duration * 100) + '%"></i></span></label>'; }).join('') : '<div class="anatomy-tags">' + e.parts.map(n => '<span>' + n + '</span>').join('') + '</div>') + '</div></div><aside class="sidepanel"><div class="panel-head"><strong>계층형 컨피그</strong><button class="ghost small" id="resetConfig">초기화 ↺</button></div>' + ['size', 'amount', 'duration', 'opacity'].map(k => rangeHTML(k, s)).join('') + '<div class="panel-select"><label for="effectColor">주 색상</label><input type="color" id="effectColor" value="' + s.config.appearance.color + '"></div><div class="switches" style="margin-top:12px"><label style="' + (s.config.appearance.glow === undefined ? 'display:none' : '') + '"><input id="glowToggle" type="checkbox" checked>외곽 발광</label><label><input id="guideToggle" type="checkbox" checked>기준점</label></div>' + (specifics(e.id).length ? '<details class="panel-section" open><summary>모양·움직임 세부 조절</summary>' + specifics(e.id).map(k => rangeHTML(k, s)).join('') + '</details>' : '') + '<div class="panel-section"><div class="panel-select" style="margin-top:0"><label for="sceneBg">관찰 배경</label><select id="sceneBg"><option value="dark">어두운 배경</option><option value="light">밝은 배경</option><option value="terrain">게임 지형</option></select></div><div class="panel-select"><label for="sceneZoom">관찰 배율</label><select id="sceneZoom"><option value="1">확대 관찰</option><option value="0.5">작게 보기 · 50%</option><option value="0.25">게임 크기 · 25%</option></select></div><div class="switches" style="margin-top:10px"><label><input type="checkbox" id="referenceToggle">옆에 크기 기준 캐릭터</label></div></div><details class="panel-section"><summary>타격감 보조 효과</summary><div class="switches"><label><input type="checkbox" data-feedback="shake">화면 흔들림</label><label><input type="checkbox" data-feedback="flash">피격 플래시</label><label><input type="checkbox" data-feedback="stop">타격 정지</label><label><input type="checkbox" data-feedback="punch">줌 펀치</label></div><p class="muted" style="font-size:10px;margin-bottom:0">실험 화면에만 적용됩니다. 지속 효과는 반복 주기의 첫 반응에 적용됩니다.</p></details><div class="panel-section"><div class="panel-select" style="margin-top:0"><label for="seedInput">고정 난수</label><input id="seedInput" class="seedbox mono" type="number" min="0" max="4294967295" step="1" value="' + s.seed + '"></div><div class="panel-buttons"><button id="newSeed">새 난수 ↻</button><button id="savePreset">프리셋 저장</button><button id="exportPreset">JSON 내보내기</button><button id="importPreset">JSON 불러오기</button><button id="editConfig">컨피그 JSON 편집</button><button id="exportCode" class="primary">게임에 가져가기 ↗</button></div></div></aside></div>';
        const stage = $('#inspectorStage');
        stage._scene = s;
        setViews();
        $('#sceneSpeed').value = String(state.speed);
        $('#sceneBg').value = state.bg;
        syncControls();
        $('#guideToggle').checked=s.showGuides;
        bindInspector();
        installDataPanel(s);
        scrollTo({ top: 0, behavior: 'instant' });
    }
    function syncControls() { const s = state.inspector; if (!s)
        return; for (const el of $$('[data-param]')) {
        const spec = parametersFor(s.effect.id).find(x => x.key === el.dataset.param), v = getPath(s.config, spec.path);
        el.min = Math.min(spec.min, v);
        el.max = Math.max(spec.max, v);
        el.value = v;
        $('#o-' + spec.key).textContent = formatParam(spec.key, v);
    } $('#effectColor').value = s.config.appearance.color; $('#glowToggle').checked = s.config.appearance.glow; $('#seedInput').value = s.seed; $('#seedLabel').textContent = s.seed; for (const el of $$('[data-layer]'))
        el.checked = s.layers[Number(el.dataset.layer)]; updatePlayback(); }
    function replay(s) { if(s.effect.family==='feedback')effects.setData(s.handle,s.data,{restart:true}); s.time = 0; s.stopRemaining = 0; s.cycle = 0; s.triggered.clear(); s.paused = false; s.history.length = 0; updatePlayback(); }
    function updatePlayback() {
        const s = state.inspector;
        if (!s || !$('#timeline'))
            return;
        $('#scenePlay').textContent = s.paused ? '▶' : 'Ⅱ';
        $('#sceneStatus').textContent = s.paused ? '일시정지' : '재생 중';
        $('#timeline').value = Math.round(elapsed(s) / timelineEnd(s) * 1000);
        $('#timeLabel').textContent = elapsed(s).toFixed(2) + ' / ' + timelineEnd(s).toFixed(2) + 's';
    }
    function bindInspector() {
        const s = state.inspector;
        $('#backBtn').onclick = () => nav(state.returnTab);
        $('#prevEffect').onclick = () => openInspector(ALL[mod(ALL.indexOf(s.effect) - 1, ALL.length)].id);
        $('#nextEffect').onclick = () => openInspector(ALL[(ALL.indexOf(s.effect) + 1) % ALL.length].id);
        $('#snapshotCompare').onclick = () => addCompare(s);
        $('#scenePlay').onclick = () => {
            if (s.time >= duration(s) - .001)
                replay(s);
            else
                s.paused = !s.paused;
            updatePlayback();
        };
        $('#sceneRestart').onclick = () => replay(s);
        $('#sceneStep').onclick = () => step(s);
        $('#sceneLoop').onchange = ev => s.loop = ev.target.checked;
        $('#sceneSpeed').onchange = ev => { state.speed = Number(ev.target.value); $('#globalSpeed').value = String(state.speed); };
        $('#timeline').oninput = ev => { s.paused = true; setElapsed(s, Number(ev.target.value) / 1000 * timelineEnd(s)); s.stopRemaining = 0; s.triggered.clear(); updatePlayback(); };
        for (const el of $$('[data-param]'))
            el.oninput = () => {
                let normalized = s.time / duration(s);
                applyConfig(s, patchAt(parametersFor(s.effect.id).find(p => p.key === el.dataset.param).path, Number(el.value)));
                if (el.dataset.param === 'duration')
                    s.time = normalized * duration(s);
                $('#o-' + el.dataset.param).textContent = formatParam(el.dataset.param, Number(el.value));
                updatePlayback();
            };
        $('#effectColor').oninput = ev => applyConfig(s, { appearance: { color: ev.target.value } });
        $('#glowToggle').onchange = ev => applyConfig(s, { appearance: { glow: ev.target.checked } });
        $('#guideToggle').onchange = ev => s.showGuides = ev.target.checked;
        $('#sceneBg').onchange = ev => { state.bg = ev.target.value; $('#globalBg').value = state.bg; };
        $('#sceneZoom').onchange = ev => { s.zoom = Number(ev.target.value); $('#scaleHint').textContent = s.zoom === 1 ? '기본 관찰 크기' : s.zoom === .5 ? '50% 크기' : '25% 크기 · 가독성 확인'; };
        $('#referenceToggle').onchange = ev => s.showReference = ev.target.checked;
        for (const el of $$('[data-feedback]'))
            el.onchange = () => s.feedback[el.dataset.feedback] = el.checked;
        for (const el of $$('[data-layer]'))
            el.onchange = () => s.layers[Number(el.dataset.layer)] = el.checked;
        $('#resetConfig').onclick = () => { replaceConfig(s, defaults(s.effect)); syncControls(); toast('파라미터를 기본값으로 되돌렸어요.'); };
        $('#seedInput').onchange = ev => {
            const v = Number(ev.target.value);
            if (!Number.isInteger(v) || v < 0 || v > 4294967295) {
                toast('0–4294967295 사이의 정수를 입력해 주세요.');
                ev.target.value = s.seed;
                return;
            }
            s.seed = v;
            $('#seedLabel').textContent = v;
            replay(s);
        };
        $('#newSeed').onclick = () => {
            let a = new Uint32Array(1);
            if (window.crypto)
                crypto.getRandomValues(a);
            else
                a[0] = Math.floor(Math.random() * 4294967296);
            s.seed = a[0];
            $('#seedInput').value = s.seed;
            $('#seedLabel').textContent = s.seed;
            replay(s);
        };
        $('#savePreset').onclick = () => saveDialog(s);
        $('#exportPreset').onclick = () => jsonDialog(capture(s));
        $('#importPreset').onclick = () => jsonDialog();
        $('#editConfig').onclick = () => configDialog(s);
        $('#exportCode').onclick = () => exportDialog(s);
        const stage = $('#inspectorStage');
        let drag = null;
        function coords(ev) { const r = stage.getBoundingClientRect(), scale = Math.min(r.width / 320, r.height / 205) * s.zoom; return { x: clamp((ev.clientX - r.left - r.width / 2) / scale, -140, 140), y: clamp((ev.clientY - r.top - r.height / 2) / scale, -80, 65) }; }
        function apply(ev) {
            const q = coords(ev);
            if (drag === 'source' || drag === 'target')
                s[drag] = q;
            else if (drag === 'shield')
                s.hitAngle = Math.atan2(q.y - s.origin.y - 7, q.x - s.origin.x);
            else if (drag === 'actor') {
                s.actor = q;
                s.interacted = true;
                s.history.push({ ...q });
                if (s.history.length > 80)
                    s.history.shift();
            }
            else
                s.origin = q;
        }
        stage.onpointerdown = ev => {
            if (ev.button > 0)
                return;
            stage.focus({ preventScroll: true });
            const q = coords(ev);
            if (TARGETED.has(s.effect.id) || s.effect.type === 'combo') {
                let da = Math.hypot(q.x - s.source.x, q.y - s.source.y), db = Math.hypot(q.x - s.target.x, q.y - s.target.y);
                drag = da < db ? 'source' : 'target';
            }
            else
                drag = s.effect.id === 'shield' ? 'shield' : s.effect.id === 'dash' ? 'actor' : 'origin';
            stage.setPointerCapture(ev.pointerId);
            apply(ev);
            replay(s);
            ev.preventDefault();
        };
        stage.onpointermove = ev => {
            if (drag) {
                apply(ev);
                ev.preventDefault();
            }
        };
        stage.onpointerup = ev => {
            drag = null;
            if (stage.hasPointerCapture(ev.pointerId))
                stage.releasePointerCapture(ev.pointerId);
        };
        stage.onpointercancel = () => drag = null;
    }
    function step(s) {
        s.paused = true;
        if (s.effect.type === 'continuous' && s.loop)
            setElapsed(s, elapsed(s) + 1 / 60);
        else
            s.time = Math.min(duration(s), s.time + 1 / 60);
        s.stopRemaining = 0;
        updatePlayback();
    }
    function renderCompare() {
        state.inspector = null;
        state.compareTime = 0;
        updateTabs();
        let content = '<div class="workspace-head"><div><div class="eyebrow">SIDE BY SIDE / SNAPSHOT COMPARISON</div><h2>같은 조건에서 비교하기</h2><div class="muted" style="font-size:12px">설정값을 고정하고 같은 경과 시간을 비교합니다. 짧은 효과는 종료 프레임을 유지해요.</div></div><button id="backAtlas" class="small">＋ 도감에서 추가</button></div>';
        if (!state.compare.length) {
            $('#main').innerHTML = content + '<div class="empty">비교 슬롯이 비어 있어요.<br>도감의 ＋ 버튼 또는 확대 화면의 「현재 값 비교 보관」을 눌러 주세요.</div>';
            $('#backAtlas').onclick = () => nav('atlas');
            setViews();
            return;
        }
        content += '<div class="playback"><button id="comparePlay" class="small">' + (state.paused ? '▶ 전체 재생' : 'Ⅱ 전체 정지') + '</button><button id="compareRestart" class="small">↺ 동시 재생</button><button id="compareStep" class="small">▹ 한 프레임</button><input type="range" id="compareTime" min="0" max="1000" step="1" value="0" aria-label="비교 공통 시간"><span class="mono" id="compareTimeLabel">0.00s</span><select id="compareBg" aria-label="비교 배경"><option value="dark">어두운 배경</option><option value="light">밝은 배경</option><option value="terrain">게임 지형</option></select><label><input id="syncSeed" type="checkbox">같은 난수</label></div><div class="compare-grid">';
        for (let i = 0; i < state.compare.length; i++) {
            let d = state.compare[i];
            content += '<article class="compare-card"><div class="compare-head"><div><b class="mono" style="color:var(--mint);margin-right:8px">' + String.fromCharCode(65 + i) + '</b>' + safeText(d.name) + '<br><small>크기 ' + d.config.appearance.scale.toFixed(2) + ' · 밀도 ' + (d.config.emission?.density ?? 1).toFixed(2) + ' · 수명 ' + (d.config.lifetime.durationMs / 1000).toFixed(2) + 's</small></div><div><button class="small" data-edit-slot="' + i + '">열기</button> <button class="small ghost" data-remove-slot="' + i + '" aria-label="비교 슬롯 삭제">×</button></div></div><div class="stage" data-scene="compare-' + i + '"><span class="stage-label mono">' + BY_ID[d.effect].tech + '</span><span class="stage-foot mono">SEED ' + d.seed + '</span></div></article>';
        }
        content += '</div>';
        $('#main').innerHTML = content;
        for (let i = 0; i < state.compare.length; i++) {
            $('[data-scene="compare-' + i + '"]')._scene = restore(state.compare[i], 'compare');
        }
        setViews();
        $('#backAtlas').onclick = () => nav('atlas');
        $('#compareBg').value = state.bg;
        $('#compareBg').onchange = ev => { state.bg = ev.target.value; $('#globalBg').value = state.bg; };
        $('#comparePlay').onclick = () => { state.paused = !state.paused; $('#comparePlay').textContent = state.paused ? '▶ 전체 재생' : 'Ⅱ 전체 정지'; $('#globalPlay').textContent = state.paused ? '▶ 전체 재생' : 'Ⅱ 전체 정지'; };
        $('#compareRestart').onclick = () => {
            state.compareTime = 0;
            for (const v of views) {
                v.scene.time = 0;
                v.scene.paused = false;
            }
            state.paused = false;
            $('#comparePlay').textContent = 'Ⅱ 전체 정지';
        };
        $('#compareStep').onclick = () => {
            state.paused = true;
            const max = Math.max(...views.map(v => duration(v.scene)));
            state.compareTime = Math.min(max, state.compareTime + 1 / 60);
            for (const v of views) {
                v.scene.time = Math.min(duration(v.scene), state.compareTime);
                v.scene.paused = false;
            }
            $('#comparePlay').textContent = '▶ 전체 재생';
        };
        $('#compareTime').oninput = ev => {
            state.paused = true;
            const max = Math.max(...views.map(v => duration(v.scene))), t = Number(ev.target.value) / 1000 * max;
            state.compareTime = t;
            for (const v of views) {
                v.scene.time = Math.min(duration(v.scene), t);
                v.scene.paused = false;
            }
            $('#comparePlay').textContent = '▶ 전체 재생';
        };
        $('#syncSeed').onchange = ev => {
            state.compareTime = 0;
            for (let i = 0; i < views.length; i++) {
                views[i].scene.seed = ev.target.checked ? state.compare[0].seed : state.compare[i].seed;
                views[i].scene.time = 0;
                views[i].el.querySelector('.stage-foot').textContent = 'SEED ' + views[i].scene.seed;
            }
        };
    }
    function renderPresets() { state.inspector = null; updateTabs(); $('#main').innerHTML = '<div class="workspace-head"><div><div class="eyebrow">SAVED EXPERIMENTS</div><h2>내 프리셋</h2><div class="muted" style="font-size:12px">' + (persistentStorage ? '이 브라우저에 저장됩니다. 다른 환경으로 옮길 때는 JSON을 사용하세요.' : '브라우저 저장이 제한되어 이 창에서만 보관됩니다. 창을 닫기 전에 JSON으로 저장하세요.') + '</div></div><button class="small primary" id="presetImport">JSON 불러오기</button></div>' + (state.presets.length ? '<div class="preset-grid">' + state.presets.map((d, i) => '<article class="preset-card"><span class="eyebrow">' + safeText(BY_ID[d.effect].tech) + '</span><h3>' + safeText(d.name) + '</h3><p>' + BY_ID[d.effect].name + ' · 크기 ' + d.config.appearance.scale.toFixed(2) + ' · 밀도 ' + (d.config.emission?.density ?? 1).toFixed(2) + '</p><button class="small primary" data-open-preset="' + i + '">실험실에서 열기</button> <button class="small" data-json-preset="' + i + '">JSON</button> <button class="small ghost" data-delete-preset="' + i + '" aria-label="프리셋 삭제">×</button></article>').join('') + '</div>' : '<div class="empty">아직 저장한 프리셋이 없어요.<br>효과를 열어 값을 조절한 뒤 「프리셋 저장」을 눌러 주세요.</div>'); setViews(); $('#presetImport').onclick = () => jsonDialog(); }
    let dialogPreviousFocus = null;
    function closeDialog() {
        const prev = dialogPreviousFocus;
        $('#dialogHost').innerHTML = '';
        document.body.style.overflow = '';
        if (prev && prev.isConnected)
            prev.focus({ preventScroll: true });
    }
    function dialog(html) {
        dialogPreviousFocus = document.activeElement;
        $('#dialogHost').innerHTML = '<div class="dialog-wrap"><section class="dialog" role="dialog" aria-modal="true" aria-labelledby="dialogTitle">' + html + '</section></div>';
        document.body.style.overflow = 'hidden';
        $('.dialog-wrap').addEventListener('click', ev => {
            if (ev.target.classList.contains('dialog-wrap'))
                closeDialog();
        });
        $('.dialog').querySelector('input,textarea,button')?.focus();
    }
    function saveDialog(s) {
        dialog('<h2 id="dialogTitle">실험값을 프리셋으로 저장</h2><p>효과 설정·고정 난수·시작점과 표적·조합 레이어를 함께 저장합니다.</p><input type="text" id="presetName" maxlength="80" aria-label="프리셋 이름" value="' + safeText(s.effect.name + ' · 실험 1') + '"><div class="dialog-actions"><button id="cancelSave">취소</button><button class="primary" id="confirmSave">저장</button></div>');
        $('#cancelSave').onclick = closeDialog;
        $('#confirmSave').onclick = () => {
            const name = $('#presetName').value.trim() || s.effect.name;
            state.presets.push(capture(s, name));
            const ok = persist();
            closeDialog();
            if (ok)
                toast('「' + name + '」을 저장했어요.');
        };
        $('#presetName').onkeydown = ev => {
            if (ev.key === 'Enter')
                $('#confirmSave').click();
        };
    }
    function jsonDialog(data = null) {
        const exporting = !!data;
        dialog('<h2 id="dialogTitle">' + (exporting ? '프리셋 JSON 내보내기' : '프리셋 JSON 불러오기') + '</h2><p>' + (exporting ? '설정값과 고정 난수, 좌표를 그대로 재사용할 수 있어요. 파일이나 텍스트로 보관하세요.' : '이 연구소에서 내보낸 JSON을 붙여 넣거나 파일을 선택하세요.') + '</p><textarea id="jsonText" spellcheck="false" aria-label="프리셋 JSON">' + (data ? safeText(JSON.stringify(data, null, 2)) : '') + '</textarea><div class="error" id="jsonError"></div><input id="jsonFile" type="file" accept=".json,application/json" class="hidden"><div class="dialog-actions"><button id="jsonClose">닫기</button>' + (exporting ? '<button id="jsonDownload">파일 저장</button><button class="primary" id="jsonCopy">JSON 복사</button>' : '<button id="jsonChoose">파일 선택</button><button class="primary" id="jsonApply">불러와서 실험</button>') + '</div>');
        $('#jsonClose').onclick = closeDialog;
        if (exporting) {
            $('#jsonCopy').onclick = async () => {
                let text = $('#jsonText').value;
                try {
                    if (navigator.clipboard && window.isSecureContext)
                        await navigator.clipboard.writeText(text);
                    else {
                        const el = $('#jsonText');
                        el.select();
                        if (!document.execCommand('copy'))
                            throw Error('copy');
                    }
                    toast('JSON을 복사했어요.');
                }
                catch (e) {
                    $('#jsonText').select();
                    $('#jsonError').textContent = '자동 복사가 제한되어 있어요. 선택된 텍스트를 Ctrl+C로 복사해 주세요.';
                }
            };
            $('#jsonDownload').onclick = () => { const blob = new Blob([$('#jsonText').value], { type: 'application/json' }), url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = data.effect + '-preset.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); };
        }
        else {
            $('#jsonChoose').onclick = () => $('#jsonFile').click();
            $('#jsonFile').onchange = async (ev) => {
                const f = ev.target.files[0];
                if (!f)
                    return;
                if (f.size > 1024 * 1024) {
                    $('#jsonError').textContent = '1MB 이하의 프리셋 파일만 읽을 수 있어요.';
                    return;
                }
                try {
                    $('#jsonText').value = await f.text();
                }
                catch (e) {
                    $('#jsonError').textContent = '파일을 읽을 수 없어요.';
                }
            };
            $('#jsonApply').onclick = () => {
                try {
                    const raw = JSON.parse($('#jsonText').value), d = validatePreset(raw);
                    state.presets.push(d);
                    persist();
                    closeDialog();
                    openInspector(d.effect, d);
                    toast('프리셋을 불러왔어요.');
                }
                catch (e) {
                    $('#jsonError').textContent = e instanceof SyntaxError ? 'JSON 문법이 올바르지 않아요. 중괄호와 따옴표를 확인해 주세요.' : e.message;
                }
            };
        }
    }
    function helpDialog() { dialog('<h2 id="dialogTitle">GameKit 기반 파티클 연구소</h2><p>68종·6개 조합을 같은 실행 모듈로 비교합니다. 도감 밖 카드는 정지하고, 확대 화면에서 Space·R·마침표로 재생을 제어합니다.</p><p><b>컨피그 JSON 편집</b>은 부분 설정도 받습니다. 숫자 슬라이더는 권장 범위일 뿐이며, JSON으로 그 범위를 벗어난 유효값을 넣을 수 있습니다.</p><p><b>게임에 가져가기</b>에서 이펙트 ESM·현재 프리셋·독립 예제를 추출하세요. 기존 게임의 WebGLDevice를 전달하면 동일 코드로 렌더링합니다. 시계는 ms입니다.</p><p>이펙트에 충돌 판정·피해·게임 규칙은 없습니다. 실제 피격 이벤트는 게임이 제공합니다. 게임의 경로·궤적·도형은 실행 인자로 전달합니다.</p><p>GPU 자원은 bloom-gamekit의 WebGLDevice, 롤백 중복·취소는 선택적으로 PresentationEventQueue를 사용합니다. 두 원본 파일은 변경 없이 내장했습니다. 커밋 <code>' + provenance.commit + '</code>.</p><p>단일 HTML은 네트워크를 사용하지 않습니다. 시연용 막대 캐릭터는 연구소에서만 주입합니다. 화면 FPS는 이 환경의 수치이며 다른 기기 성능을 보장하지 않습니다.</p><div class="dialog-actions"><button class="primary" id="closeHelp">확인</button></div>'); $('#closeHelp').onclick = closeDialog; }
    const keys = new Set();
    document.addEventListener('keydown', ev => {
        const tag = ev.target.tagName;
        if ($('#dialogHost').children.length) {
            if (ev.key === 'Escape')
                closeDialog();
            else if (ev.key === 'Tab') {
                const f = [...$('.dialog').querySelectorAll('button,input:not(.hidden),textarea,a,summary')].filter(x => x.offsetParent !== null), first = f[0], last = f[f.length - 1];
                if (ev.shiftKey && document.activeElement === first) {
                    ev.preventDefault();
                    last.focus();
                }
                else if (!ev.shiftKey && document.activeElement === last) {
                    ev.preventDefault();
                    first.focus();
                }
            }
            return;
        }
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag))
            return;
        const k = ev.key.toLowerCase();
        if (['arrowleft', 'arrowright', 'arrowup', 'arrowdown', 'w', 'a', 's', 'd'].includes(k) && state.inspector?.effect.id === 'dash') {
            ev.preventDefault();
            keys.add(k);
        }
        if (ev.code === 'Space') {
            ev.preventDefault();
            if (state.inspector) {
                state.inspector.paused = !state.inspector.paused;
                updatePlayback();
            }
            else {
                state.paused = !state.paused;
                $('#globalPlay').textContent = state.paused ? '▶ 전체 재생' : 'Ⅱ 전체 정지';
                if ($('#comparePlay'))
                    $('#comparePlay').textContent = $('#globalPlay').textContent;
            }
        }
        else if (k === 'r') {
            if (state.inspector)
                replay(state.inspector);
            else
                for (const v of views)
                    replay(v.scene);
        }
        else if (k === '.' && state.inspector) {
            step(state.inspector);
        }
        else if (k === 'escape' && state.inspector)
            nav(state.returnTab);
    });
    document.addEventListener('keyup', ev => keys.delete(ev.key.toLowerCase()));
    window.addEventListener('blur', () => keys.clear());
    for (const b of $$('.tab'))
        b.onclick = () => nav(b.dataset.tab);
    $('#filters').onclick = ev => {
        const b = ev.target.closest('[data-category]');
        if (b) {
            state.category = b.dataset.category;
            renderGallery();
        }
    };
    $('#search').oninput = ev => { state.query = ev.target.value; renderGallery(); };
    $('#globalPlay').onclick = () => { state.paused = !state.paused; $('#globalPlay').textContent = state.paused ? '▶ 전체 재생' : 'Ⅱ 전체 정지'; };
    $('#globalReset').onclick = () => {
        for (const s of sceneCache.values()) {
            s.time = 0;
            s.cycle = 0;
            s.triggered.clear();
            s.stopRemaining = 0;
        }
        toast('같은 난수로 처음부터 재생해요.');
    };
    $('#globalSpeed').onchange = ev => state.speed = Number(ev.target.value);
    $('#globalBg').onchange = ev => state.bg = ev.target.value;
    $('#cardSize').onchange = ev => { state.size = ev.target.value; $('#effectGrid').className = 'grid ' + (state.size === 'normal' ? '' : state.size); };
    $('#openCompare').onclick = () => nav('compare');
    $('#clearCompare').onclick = () => { state.compare = []; updateTabs(); updateComparisonButtons(); };
    $('#helpBtn').onclick = helpDialog;
    $('#importTop').onclick = () => jsonDialog();
    $('#app').addEventListener('click', ev => {
        const pause = ev.target.closest('[data-pause]');
        if (pause) {
            let s = galleryScene(BY_ID[pause.dataset.pause]);
            s.paused = !s.paused;
            pause.textContent = s.paused ? '▶' : 'Ⅱ';
            return;
        }
        const comp = ev.target.closest('[data-compare]');
        if (comp) {
            addCompare(galleryScene(BY_ID[comp.dataset.compare]));
            return;
        }
        const edit = ev.target.closest('[data-edit-slot]');
        if (edit) {
            const p = state.compare[Number(edit.dataset.editSlot)];
            openInspector(p.effect, p);
            return;
        }
        const open = ev.target.closest('[data-open-preset]');
        if (open) {
            const p = state.presets[Number(open.dataset.openPreset)];
            openInspector(p.effect, p);
            return;
        }
        const json = ev.target.closest('[data-json-preset]');
        if (json) {
            jsonDialog(state.presets[Number(json.dataset.jsonPreset)]);
            return;
        }
        const del = ev.target.closest('[data-delete-preset]');
        if (del) {
            state.presets.splice(Number(del.dataset.deletePreset), 1);
            persist();
            renderPresets();
            toast('프리셋을 삭제했어요.');
        }
    });
    document.addEventListener('click', ev => {
        const b = ev.target.closest('[data-remove-slot]');
        if (!b)
            return;
        state.compare.splice(Number(b.dataset.removeSlot), 1);
        if (state.tab === 'compare' && !state.inspector)
            renderCompare();
        else {
            updateTabs();
            updateComparisonButtons();
        }
    });
    function background(s) {
        const light = state.bg === 'light', color = light ? '#82908b' : state.bg === 'terrain' ? '#739d82' : '#506573', halfW = R.rect.width / R.s / 2, halfH = R.rect.height / R.s / 2;
        for (let x = Math.ceil(-halfW / 24) * 24; x < halfW; x += 24)
            for (let y = Math.ceil(-halfH / 24) * 24; y < halfH; y += 24)
                R.disc(x, y, .5, color, .3);
        if (state.bg === 'terrain') {
            for (let i = 0; i < 12; i++) {
                let x = (rand(i, 902) - .5) * 290, y = 15 + rand(i + 100, 902) * 65, r = 6 + rand(i + 34, 902) * 15;
                R.puff(x, y, r, r * .3, '#587157', .2, i);
            }
            R.line(-halfW, 40, halfW, 40, 1, '#557560', .35);
        }
        if (s.kind === 'inspector' && s.showGuides) {
            R.line(-halfW, 40, halfW, 40, .7, color, .35);
            R.line(-7, 0, 7, 0, .6, color, .38);
            R.line(0, -7, 0, 7, .6, color, .38);
        }
    }
    function hits(s) { if (s.config.timeline)
        return s.config.timeline.markersMs.map(v => v / 1000); return ({ landing: [.7], projectile: [2.02], smash: [.22], ice: [.24], thrust: [.3] })[s.effect.id] || [.06]; }
    function updateScene(s, dt) {
        if (s.kind === 'compare')
            return;
        if ((s.kind !== 'inspector' && state.paused) || s.paused)
            return;
        if (s.kind === 'inspector' && s.effect.id === 'dash' && keys.size) {
            let dx = (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0), dy = (keys.has('s') || keys.has('arrowdown') ? 1 : 0) - (keys.has('w') || keys.has('arrowup') ? 1 : 0), norm = Math.hypot(dx, dy) || 1;
            s.actor.x = clamp(s.actor.x + dx / norm * dt * 120, -125, 125);
            s.actor.y = clamp(s.actor.y + dy / norm * dt * 120, -40, 60);
            s.interacted = true;
        }
        if (s.interacted) {
            s.history.push({ ...s.actor });
            if (s.history.length > 80)
                s.history.shift();
        }
        if (s.stopRemaining > 0) {
            s.stopRemaining = Math.max(0, s.stopRemaining - dt);
            return;
        }
        let old = s.time / (duration(s) / s.effect.duration);
        s.time += dt * state.speed;
        let t = s.time / (duration(s) / s.effect.duration);
        if (s.kind === 'inspector' && s.feedback.stop) {
            for (const h of hits(s))
                if (old < h && t >= h && !s.triggered.has(h)) {
                    s.time = h * (duration(s) / s.effect.duration);
                    s.stopRemaining = .065;
                    s.triggered.add(h);
                    break;
                }
        }
        const d = duration(s);
        if (s.time >= d) {
            if (s.loop) {
                s.time = mod(s.time, d);
                s.cycle++;
                s.triggered.clear();
            }
            else {
                s.time = d;
                s.paused = true;
            }
        }
    }
    function renderScene(s, rect) {
        const baseScale = Math.min(rect.width / 320, rect.height / 205), ratio = duration(s) / s.effect.duration;
        R.begin({ width: innerWidth, height: innerHeight, clip: rect, transform: { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2, scale: baseScale } });
        R.quad(0, 0, rect.width / baseScale / 2 + .1, rect.height / baseScale / 2 + .1, state.bg === 'light' ? '#e7e9e5' : state.bg === 'terrain' ? '#1b2b28' : '#0d151e', 1);
        background(s);
        const baseTx = R.tx, baseTy = R.ty, baseS = R.s;
        R.s *= s.zoom;
        const phase = Math.min(s.time / ratio, s.effect.duration - .00001), t = phase + (s.effect.type === 'continuous' && s.kind !== 'compare' ? s.cycle * s.effect.duration : 0);
        let env = 0;
        for (const h of hits(s)) {
            const d = phase - h;
            if (d >= 0 && d < .32)
                env = Math.max(env, Math.exp(-d * 16));
        }
        if (s.kind === 'inspector') {
            if (s.feedback.shake) {
                R.tx += Math.sin(t * 127) * env * 4 * R.s;
                R.ty += Math.cos(t * 113) * env * 2.8 * R.s;
            }
            if (s.feedback.punch)
                R.s *= 1 + env * .075;
        }
        if (s.effect.type === 'combo')
            previewCombination(s, t);
        const position = TARGETED.has(s.effect.id) || s.effect.type === 'combo' ? point(0, 0) : s.effect.id === 'dash' && s.interacted ? s.actor : s.origin;
        effects.setAnchors(s.handle, { position, source: s.source, target: s.target, hitAngle: s.hitAngle, layers: s.layers, trail: s.interacted ? s.history : [] });
        effects.setSeed(s.handle, s.seed);
        const ageMs = s.effect.type === 'continuous' && s.effect.family!=='feedback' && s.kind !== 'compare' ? (s.cycle * duration(s) + s.time) * 1000 : Math.min(s.time * 1000, s.config.lifetime.durationMs - .001);
        // Inspector/gallery use explicit sampling so seeking has no simulation side effects.
        effects.seek(s.handle, ageMs);
        effects.draw(s.handle);
        if (s.kind === 'inspector' && s.showGuides) {
            if (TARGETED.has(s.effect.id) || s.effect.type === 'combo') {
                for (const [q, col] of [[s.source, '#a5f1ce'], [s.target, '#ffbd91']]) {
                    R.ring(q.x, q.y, 7, .8, col, .7);
                    R.disc(q.x, q.y, 2, col, .9);
                }
            }
            else if (s.effect.id !== 'dash') {
                R.line(s.origin.x - 5, s.origin.y, s.origin.x + 5, s.origin.y, .7, '#9bc1b2', .5);
                R.line(s.origin.x, s.origin.y - 5, s.origin.x, s.origin.y + 5, .7, '#9bc1b2', .5);
            }
        }
        R.tx = baseTx;
        R.ty = baseTy;
        R.s = baseS;
        if (s.kind === 'inspector' && s.feedback.flash && env > 0)
            R.quad(0, 0, rect.width / baseS / 2, rect.height / baseS / 2, s.config.appearance.color, env * .10);
        if (s.kind === 'inspector' && s.showReference) {
            character(118, 56, .52, state.bg === 'light' ? '#455b54' : '#9ab5aa', .75);
            R.line(106, 56, 130, 56, .8, '#7f9a8e', .5);
        }
        R.end();
    }
    function frame(now) {
        const rawDt = lastTime ? Math.max(.001, (now - lastTime) / 1000) : 1 / 60, dt = Math.min(.2, rawDt);
        lastTime = now;
        if (!document.hidden) {
            if (state.tab === 'compare' && !state.inspector && views.length) {
                const max = Math.max(...views.map(v => duration(v.scene)));
                if (!state.paused)
                    state.compareTime = mod(state.compareTime + dt * state.speed, max);
                for (const v of views)
                    v.scene.time = Math.min(duration(v.scene), state.compareTime);
            }
            renderFrame(dt);
            frames++;
            fpsTime += rawDt;
            if (fpsTime >= .5) {
                fps = frames / fpsTime;
                fpsTime = 0;
                frames = 0;
                $('#performance').textContent = 'GameKit · ' + Math.round(fps) + ' FPS · ' + R.activeViews + ' 뷰';
                if ($('#viewStats'))
                    $('#viewStats').textContent = R.vertices.toLocaleString() + ' 버텍스 · ' + device.stats.drawCalls + ' 드로콜';
                drawStats = { fps, views: R.activeViews, vertices: R.vertices, drawCalls: device.stats.drawCalls, bufferBytes: R.data.byteLength, instances: effects.size, sourceCommit: provenance.commit };
            }
            if (state.inspector)
                updatePlayback();
            if (state.tab === 'compare' && !state.inspector && views.length && $('#compareTime')) {
                const max = Math.max(...views.map(v => duration(v.scene)));
                $('#compareTime').value = state.compareTime / max * 1000;
                $('#compareTimeLabel').textContent = state.compareTime.toFixed(2) + 's';
            }
        }
        raf = requestAnimationFrame(frame);
    }
    document.addEventListener('visibilitychange', () => { lastTime = 0; keys.clear(); });
    // Development/test surface: it invokes the same visible scene and renderer as the UI.
    window.PARTICLE_LAB = { version: '3.0-feedback-gamekit', effects: EFFECTS.map(e => ({ id: e.id, name: e.name })), combos: COMBOS.map(e => ({ id: e.id, name: e.name })), get state() { return state; }, get views() { return views; }, get stats() { return { ...drawStats }; }, get renderer() { return R; }, device, runtime: effects, open: openInspector, nav, validatePreset, capture, restore, renderNow() { renderFrame(); }, seek(seconds) { if (state.inspector) {
            setElapsed(state.inspector, seconds);
            state.inspector.paused = true;
            updatePlayback();
            renderFrame();
        } }, seekMs(milliseconds) { this.seek(milliseconds / 1000); }, configure(patch) { if (!state.inspector)
            throw Error('먼저 효과를 여세요.'); applyConfig(state.inspector, patch); renderFrame(); return state.inspector.config; }, getGLerror() { return device.gl.getError(); }, makeStandalone, sourceText, dispose() { cancelAnimationFrame(raf); effects.dispose(); device.dispose(); }, provenance };
    const newButton=document.getElementById('newEffects');if(newButton)newButton.onclick=()=>{state.category='new';nav('atlas');};
    renderGallery();
    requestAnimationFrame(frame);
}
