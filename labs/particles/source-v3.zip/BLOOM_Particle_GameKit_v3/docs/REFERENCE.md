# 읽은 원본과 이번 확장 범위

이 문서는 원본 코드의 반영 완료 보고서가 아니라 **연구소 효과의 설계 근거**입니다. 원본 저장소는 수정하지 않았습니다. 아래 파일은 GitHub 커넥터로 읽었습니다. 대용량 HTML은 `/git/blobs/{sha}` 응답을 통해 읽었습니다.

## 랠리 프론티어

- 저장소: https://github.com/byh-playground/rally-frontier
- 파일: `index.html`
- 읽은 Git blob: `258c43dda704f9b8d89f24de50e505066f28498e` (커밋 SHA가 아니라 파일 blob입니다)
- 관찰한 소유자/함수: `FloatingTextPresentationDefinition`, `floatFx`, `floatFxPool`, `drawWorldHudOverlay`, `drawCombatReadabilityOverlay`, `drawSelectedBuildingOverlay`, `capturePoints.progress`, `flagFx`.

피해·회복·회피·수입 등의 부유 문자 수명과 상승/페이드, 자원 반납 지점의 짧은 합산, 라인/지터를 통한 구분, 표시 개수 제한, 점령 퍼센트와 선택 표시를 참고했습니다. 숫자 효과가 `StrategySim`의 저장·체크섬·복구 상태를 소유하지 않는 경계도 유지했습니다.

이번 추가 항목 중 피해/회복/자원 숫자, 체력·보호막 게이지, 점령 진행, 선택 모서리, 집결 깃발은 이 흐름에서 추출·확장했습니다. 원본의 UI 레이아웃·게임 판정·풀 클래스를 통째로 복사하지 않고 독립된 데이터 입력과 공통 GameKit 효과로 재구성했습니다.

## 버드모리 (사용자 요청의 ‘버드모아’ 저장소)

- 저장소: https://github.com/byh-playground/budmori-io
- 파일: `index.html`, `README.md`
- 읽은 index Git blob: `3731ecb66bcbe3fba3c9bd1dd6fd033074b5a36b`
- 관찰한 함수/설정: `CONFIG.resourceGain`, `mineralGainDraw`, `mineralGainRaster`, `mineralGainOverlaps`, `WorldUI.screen`, `applyHealing`, `healingCredit`, `fmt`, 성장/카드 UI.

`resourceGain`은 수입을 짧은 창에서 합산하고 지갑 배지를 강조하며 화면 밖·겹침·표시 개수를 관리합니다. 표시가 제한되어도 실제 지갑 수입을 깎지 않는 경계를 참고했습니다. `healingCredit`의 실제 HP 증분, 성장 수치의 before → after/작은 차이 식별, 성장 카드·합성·해금·공격 예고 흐름도 참고했습니다.

수입 채널은 **호스트가 주는 안정적인 key 기준**으로 합산합니다. 원본의 공간 군집 반경·화면 레이블 충돌 회피·가림 처리까지 자동 이식한 것은 아닙니다. 해당 정책은 게임 좌표/카메라/시야를 아는 호스트에 남습니다.

## 두 게임에서 확장한 새로운 예시

자릿수 롤링, 카운트업, 피해 잔상 게이지, 분할 게이지, 버튼 탄성, 실패 흔들림, 포털이 아닌 보상 회수와 숫자 반영, 카드 폭 뒤집기, 희귀 보상 표식 등은 원본과 일대일로 같은 효과가 있다는 뜻이 아닙니다. 실제 게임의 값 변화·상태 피드백 흐름에서 **연구소용 재사용 프리셋을 새로 설계**했습니다.

## 공통 개발규칙

- 파일: https://github.com/byh-playground/bloom-reference/blob/main/rules/development.html
- 읽은 Git blob: `3a26e2b7f1dc54c0106bb9d1e49ffe4f709f697f`
- 적용: 권위 상태/표현 상태 분리, 중첩 인스턴스 설정, 실제 소비되는 설정만 노출, 명시적 생명주기, GPU 소유권 분리, 시간 정책 중복 제거.

## GameKit 의존성

모듈은 v2의 원본 GameKit `421e04145c89b827d280f5774e8d502486cc3074`를 그대로 사용합니다. vendor 바이트/SHA-256은 `provenance.json`에서 확인합니다. 현재 게임 index에 포함된 다른 SDK 버전을 이 패키지로 덮어쓰면 안 됩니다. 게임 소유 디바이스의 공개 API와 호환되는 형태로 모듈만 연결하세요.

실제 게임 통합, 최신 SDK 업그레이드, 리포지터리 커밋·PR·푸시·배포는 이번 범위가 아닙니다.
