# 신규 28종: 데이터와 설정 계약

`data`는 실제 숫자·목표·표시 문자열입니다. `config`는 그 값을 표현하는 방식입니다. 데모의 값은 카탈로그 `demo`에 있고 런타임 기본값으로 숨어 있지 않습니다.

| 분류 | ID | 효과 | 주요 입력 |
|---|---|---|---|
| 수치 | damage_number | 피해 숫자 | to=실제 피해량 |
| 수치 | critical_number | 치명타 숫자 | to=실제 피해량 |
| 수치 | healing_number | 회복 숫자 | to=실제 HP 증가 |
| 수치 | resource_number | 수입 합산 숫자 | to=단일/합산 수입; events=시연 시간표 |
| 수치 | count_up | 카운트업·다운 | from/to; max=아랫줄 비율의 분모; label |
| 수치 | digit_roll | 자릿수 롤링 | from/to; 소수·축약은 config.format |
| 수치 | delta_number | 이전값·현재값·증감 | from/to |
| 수치 | combo_counter | 연속 합계·횟수 | from/events; 시간표 없으면 to/count |
| 게이지 | health_trail | 체력·피해 잔상 | from=이전HP, to=새HP, max=최대HP |
| 게이지 | shield_gauge | 체력·보호막 이중 막대 | from/to=보호막, secondary=현재HP, max=각 막대 분모 |
| 게이지 | radial_cooldown | 원형 쿨다운 | from/to=표시할 남은 시간, max=전체 시간 |
| 게이지 | segmented_gauge | 분할 충전 | from/to/max; segments/gap은 config |
| 게이지 | capture_meter | 점령 진행 | from/to/max; 예시는 0..100과 % 접미사 |
| 게이지 | xp_level | 경험치·레벨 넘김 | from/to=누적값, max=레벨당 임계값, count=시작 레벨 |
| UI | button_spring | 버튼 눌림·반동 | 숫자 입력 불필요; UiMotion으로 실제 버튼 재사용 |
| UI | attention_ping | 숫자 배지·알림 링 | to=배지 개수 |
| UI | toast_slide | 등장·유지·퇴장 토스트 | to/label |
| UI | denied_shake | 부족·불가 흔들림 | to/label; UiMotion 재사용 가능 |
| UI | card_reveal | 카드 앞면 공개 | to/label; front 판정은 UiMotion에도 제공 |
| UI | focus_brackets | 선택 모서리 | 입력 불필요; position으로 대상 지정 |
| 보상 | loot_transfer | 조각 회수·도착 시 숫자 반영 | from/to; source/target; reward.count/flightMs |
| 보상 | level_up | 레벨 선언 | to=새 레벨 |
| 보상 | unlock_burst | 잠금 해제 | position |
| 보상 | rarity_beacon | 희귀 보상 빛기둥 | position, appearance.color |
| 전술 | attack_warning | 부채꼴 시전 예고 | from/to/max; indicator.rotationRad/sweepRad |
| 전술 | direction_indicator | 목표 방향 화살표 | source/target; position=표시 중심 |
| 전술 | rally_marker | 집결 깃발과 링 | position=명령 위치 |
| 전술 | buff_stack | 상태 스택·만료 링 | from/to/max=시간 비율, count=스택 |

## 공통 입력

`from`, `to`, `max`, `secondary`, `count`, `label`, `events` 이외의 `data` 키는 거부됩니다. 이들은 모든 효과가 전부 읽는 필수 필드가 아닙니다. 카탈로그 표에 쓰인 값만 의미가 있으며 나머지는 정규화 기본값을 가집니다. `max`는 양수, `count`는 0..1,000,000 정수, 숫자는 유한해야 합니다. 이벤트는 최대 64개이며 시간순 `{atMs,value}`입니다.

`position`, `source`, `target`, `rotationRad`, `seed`, `clock`, `loop` 등 실행 인자는 기존 BloomEffects 계약을 그대로 사용합니다. 시연용 source/target 마커와 배경은 lab.js 소유이며 재사용 모듈의 숨은 게임 상태가 아닙니다.

## 설정 발견

```js
import {parametersFor, resolveConfig, catalog} from './bloom-effects.js';
const editable = parametersFor('health_trail'); // path/label/min/max/step/unit
const config = resolveConfig('health_trail');  // 실제 기본값과 스키마
const definition = catalog.find(x => x.id === 'health_trail');
```

슬라이더 최솟값·최댓값은 UI 권장 범위입니다. 실행 검증은 별도의 유효 범위로 동작합니다. 예: appearance.scale=10은 슬라이더 기본 범위 바깥이지만 유지됩니다. 이와 달리 게이지 칸 수·보상 조각 수처럼 명시적인 예산 필드는 정수/상한 검증을 합니다.

## 명확히 구별할 것

- **보상 회수**의 지갑 숫자는 연출용 숫자입니다. 호스트가 실제 획득을 이미 판정했어야 합니다. 조각 도착이 실제 자원 확정 시점이 되는 게임이라면 그 판정 이벤트를 게임이 별도로 소유해야 합니다.
- **원형 쿨다운/공격 예고**는 전달받은 시간/값을 표시할 뿐 실제 스킬 쿨다운이나 피해 판정을 만들지 않습니다.
- **경험치 넘김**은 일정한 `max` 임계값 예시입니다. 게임의 레벨별 비선형 경험치 공식을 재구현하지 않습니다.
- **보호막 막대**는 HP와 보호막을 두 줄로 표현하는 프리셋입니다. 최대 HP와 최대 보호막이 다른 게임에서는 비율로 정규화해 전달하거나 게임의 HUD가 각 값의 표현을 조합해야 합니다.
- **방향 안내**는 지정 위치에서 목표 방향을 표시합니다. 화면 가장자리로 자동 붙이거나 게임 안개/가림을 해석하지 않습니다.
- 모든 시계는 밀리초입니다. 숫자 자체의 단위(HP, 초, 자원)는 게임이 정하고 접미사로 표현합니다.
