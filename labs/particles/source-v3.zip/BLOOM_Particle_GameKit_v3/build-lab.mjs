import {readFile,writeFile} from 'node:fs/promises';
const root=new URL('./',import.meta.url),sources={};
for(const[key,file]of Object.entries({device:'vendor/device.js',events:'vendor/presentation-events.js',effects:'bloom-effects.js',lab:'lab.js',example:'example.js'}))sources[key]=(await readFile(new URL(file,root))).toString('base64');
const shell=await readFile(new URL('lab-shell.html',root),'utf8');
if(shell.split('__BLOOM_EMBEDDED_SOURCES__').length!==2)throw Error('HTML source marker missing');
const out=shell.replace('__BLOOM_EMBEDDED_SOURCES__',JSON.stringify(sources));
await writeFile(new URL('BLOOM_Particle_Lab_v3_GameKit.html',root),out);
console.log('BLOOM_Particle_Lab_v3_GameKit.html generated from shared sources');

const uiShell=await readFile(new URL('examples/ui-shell.html',root),'utf8');
if(uiShell.split('__BLOOM_UI_SOURCES__').length!==2)throw Error('UI source marker missing');
const uiSources={device:sources.device,effects:sources.effects,host:(await readFile(new URL('examples/ui-host.js',root))).toString('base64')};
await writeFile(new URL('examples/ui-hud-standalone.html',root),uiShell.replace('__BLOOM_UI_SOURCES__',JSON.stringify(uiSources)));
